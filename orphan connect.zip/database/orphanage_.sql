-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2021 at 01:07 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orphanage_`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_details`
--

CREATE TABLE `bank_details` (
  `orphanage_id` int(11) NOT NULL,
  `bank_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `branch` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `branch_pincode` int(6) NOT NULL,
  `acc_no` varchar(18) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `re_acc` varchar(18) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `IFSC_code` char(11) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `re_IFSC` char(11) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `UPI_id` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `re_UPI` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `bank_details`
--

INSERT INTO `bank_details` (`orphanage_id`, `bank_name`, `branch`, `branch_pincode`, `acc_no`, `re_acc`, `IFSC_code`, `re_IFSC`, `UPI_id`, `re_UPI`) VALUES
(10001, 'sbi', 'hyderabad', 555555, '987654321098', '987654321098', 'SBIN0007651', 'SBIN0007651', '7995733093', '7995733093'),
(10002, 'sbi', 'hyderabad', 555555, '62180954130', '62180954130', 'SBIN0020458', 'SBIN0020458', '8341415969', '8341415969'),
(10003, 'union bank', 'visakapatnam', 530046, '123456789', '123456789', 'SBIN0009876', 'SBIN0009876', '9908535176', '9908535176'),
(10004, 'sbi', 'hyderabad', 500049, '675432198', '675432198', 'SBIN0000981', 'SBIN0000981', '9848803541', '9848803541'),
(10005, 'sbi', 'ongole', 500049, '788888888888', '788888888888', 'SBIN0876587', 'SBIN0876587', '9390386739', '9390386739'),
(10006, 'sbi', 'ongole', 524137, '958676546787', '958676546787', 'SBIN0008686', 'SBIN0008686', '8639673280', '8639673280');

-- --------------------------------------------------------

--
-- Table structure for table `verification_details`
--

CREATE TABLE `verification_details` (
  `orphanage_id` int(11) NOT NULL,
  `orphanage_photo` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `loc_proof` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `bill` float NOT NULL,
  `manager_image` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `adhar_no` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `id_proof` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `govt_certificate` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `verification_details`
--

INSERT INTO `verification_details` (`orphanage_id`, `orphanage_photo`, `loc_proof`, `bill`, `manager_image`, `adhar_no`, `id_proof`, `govt_certificate`) VALUES
(10001, 'books.jpg', 'child 7.jpeg', 8765, 'child6.jpg', '765453432313', 'child8.jpg', 'clothes.jpg'),
(10002, 'clothes.jpg', 'newu.png', 7544, '20210221_190017_0000.png', '987654323456', 'intro.gif', 'clothes.jpg'),
(10003, 'newu.png', 'logo.png', 7654, 'child7.jpeg', '987654321987', 'child8.jpg', 'child6.jpg'),
(10004, 'icons8-clinic-50.png', 'intro.gif', 12000, 'newu.png', '765453432313', 'icons8-flour-of-rye-48.png', 'books.jpg'),
(10005, 'child6.jpg', 'medicines.jpg', 764, 'child8.jpg', '876535744357', 'newu.png', 'enrolmentpic.jpg'),
(10006, 'Screenshot (1).png', 'Screenshot (2).png', 7000, 'Screenshot (3).png', '876498742578', 'Screenshot (4).png', 'Screenshot (5).png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_details`
--
ALTER TABLE `bank_details`
  ADD PRIMARY KEY (`orphanage_id`);

--
-- Indexes for table `verification_details`
--
ALTER TABLE `verification_details`
  ADD PRIMARY KEY (`orphanage_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank_details`
--
ALTER TABLE `bank_details`
  MODIFY `orphanage_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10007;

--
-- AUTO_INCREMENT for table `verification_details`
--
ALTER TABLE `verification_details`
  MODIFY `orphanage_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10007;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
