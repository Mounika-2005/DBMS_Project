-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2021 at 01:07 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medical_emergency`
--

-- --------------------------------------------------------

--
-- Table structure for table `child_details`
--

CREATE TABLE `child_details` (
  `child_id` int(11) NOT NULL,
  `child_name` varchar(100) NOT NULL,
  `Orphanage_name` text NOT NULL,
  `Gender` enum('male','female','others') NOT NULL,
  `Dateofbirth` date NOT NULL,
  `Disease` varchar(50) NOT NULL,
  `Therapeutics` text NOT NULL,
  `Amount` int(10) NOT NULL,
  `Phone_number` bigint(10) NOT NULL,
  `Email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `child_details`
--

INSERT INTO `child_details` (`child_id`, `child_name`, `Orphanage_name`, `Gender`, `Dateofbirth`, `Disease`, `Therapeutics`, `Amount`, `Phone_number`, `Email`) VALUES
(10001, 'siddharth', 'orphan home', 'male', '2018-07-19', 'asthama', 'surgery', 100000, 7995733093, '19bcs102@iiitdwd.ac.in'),
(10002, 'sonu', 'child home', 'male', '2007-11-28', 'corona', 'treatment', 100000, 8341415969, '19bcs123@iiitdwd.ac.in');

-- --------------------------------------------------------

--
-- Table structure for table `hospital_details`
--

CREATE TABLE `hospital_details` (
  `child_id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Phone1` bigint(11) NOT NULL,
  `Phone2` bigint(11) NOT NULL,
  `Door_no` varchar(50) NOT NULL,
  `Street` varchar(50) NOT NULL,
  `Colony` varchar(50) NOT NULL,
  `Area` varchar(50) NOT NULL,
  `City` varchar(30) NOT NULL,
  `State` varchar(30) NOT NULL,
  `Pin` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hospital_details`
--

INSERT INTO `hospital_details` (`child_id`, `Name`, `Phone1`, `Phone2`, `Door_no`, `Street`, `Colony`, `Area`, `City`, `State`, `Pin`) VALUES
(10001, 'alopo', 7995733093, 7995733093, '3-5-1', 'sumitra nagar', '', 'kukatpally', 'hyderabad', 'telangana', '500049'),
(10002, 'kims', 8341415969, 8341415969, '6-200', 'katamareddy ramachandra reddy nagar', 'padugupadu', 'kovuru', 'nellore', 'Andhra Pradesh', '524137');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `child_details`
--
ALTER TABLE `child_details`
  ADD PRIMARY KEY (`child_id`);

--
-- Indexes for table `hospital_details`
--
ALTER TABLE `hospital_details`
  ADD PRIMARY KEY (`child_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `child_details`
--
ALTER TABLE `child_details`
  MODIFY `child_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10003;

--
-- AUTO_INCREMENT for table `hospital_details`
--
ALTER TABLE `hospital_details`
  MODIFY `child_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10003;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
