<!DOCTYPE html>
<html>
<head>

<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
 
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 <title>Notificatins</title>
 <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
 <style>
* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    overflow-x: hidden;
    font-family:'Trebuchet MS';
    
}
html {
    font-size: 10px;
    font-family: 'Montserrat', sans-serif;
    scroll-behavior: smooth;
    background-color:#319c8e;
}
a {
    text-decoration: none;
}
.container {
    min-height: 100vh;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
}
img {
    height: 100%;
    width: 100%;
    object-fit: cover;
}
p {
    color: black;
    font-size: 1.4rem;
    margin-top: 5px;
    line-height: 2.5rem;
    font-weight: 300;
    letter-spacing: .05rem;
}
.section-title {
    font-size: 4rem;
    font-weight: 300;
    color: black;
    margin-bottom: 10px;
    text-transform: uppercase;
    letter-spacing: .2rem;
    text-align: center;
}
.section-title span {
    color: rgb(54, 170, 179);
}

.cta {
    display: inline-block;
    padding: 10px 30px;
    color: white;
    background-color: transparent;
    border: 2px solid rgb(53, 158, 161);
    font-size: 2rem;
    text-transform: uppercase;
    letter-spacing: .1rem;
    margin-top: 30px;
    transition: .3s ease;
    transition-property: background-color, color;
}
.cta:hover {
    color: white;
    background-color:  rgb(107, 109, 109);
}
.cta2{
    display: inline-block;
    padding: 20px 40px;
    color: white;
    background-color: rgb(145, 146, 146);
    border: 2px solid rgb(53, 158, 161);
    font-size: 2rem;
    text-transform: uppercase;
    letter-spacing: .1rem;
    margin-top: 30px;
    transition: .3s ease;
    transition-property: background-color, color;
}
.cta2:hover {
    color: white;
    background-color:  rgb(107, 109, 109);
}
.brand h1 {
    font-size: 3rem;
    text-transform: uppercase;
    color: white;
   
    
}
.brand h1 span {
    color:  rgb(53, 158, 161);
    
}

.img2{
    width: 170px;
    height: 180px;
    background: transparent;
    transform: translate(-20%, -20%);
    position: absolute;
    top: 15px;
    left: 30px;
    overflow-y: hidden;
}

#header {
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 105vw;
    height: auto;
}
#header .header 
{ opacity:0.6;
    min-height: 8vh;
    background-color: #29323c;
    transition: .3s ease background-color;
}
#header .nav-bar {
    
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    height: 100%;
    max-width: 1300px;
    padding: 0 10px;
}
#header .nav-list ul {
    list-style: none;
    position: absolute;
    background-color: rgb(31, 30, 30);
    width: 100vw;
    height: 100vh;
    left: 100%;
    top: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    z-index: 1;
    overflow-x: hidden;
    transition: .5s ease left;
}
#header .nav-list ul.active {
    left: 0%;
}
#header .nav-list ul a {
    font-size: 3rem;
    font-weight: 500;
    letter-spacing: .2rem;
    text-decoration: none;
    color: white;
    text-transform: uppercase;
    padding: 30px;
    display: block;
}
#header .nav-list ul a::after {
    content: attr(data-after);
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) scale(0);
    color: rgba(240, 248, 255, 0.021);
    font-size: 15rem;
    letter-spacing: 50px;
    z-index: -1;
    transition: .3s ease letter-spacing;
}
#header .nav-list ul li:hover a::after {
    transform: translate(-50%, -50%) scale(1);
    letter-spacing: initial;
}
#header .nav-list ul li:hover a {
    color:  rgb(53, 158, 161);
}
#header .hamburger {
    height: 60px;
    width: 60px;
    display: inline-block;
    border: 3px solid white;
    border-radius: 50%;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 100;
    cursor: pointer;
    transform: scale(.8);
    margin-right: 20px;
}
#header .hamburger:after {
    position: absolute;
    content: '';
    height: 100%;
    width: 100%;
    border-radius: 50%;
    border: 3px solid white;
    animation: hamburger_puls 1s ease infinite;
}
#header .hamburger .bar {
    height: 2px;
    width: 30px;
    position: relative;
    background-color: white;
    z-index: -1;
}
#header .hamburger .bar::after,
#header .hamburger .bar::before {
    content: '';
    position: absolute;
    height: 100%;
    width: 100%;
    left: 0;
    background-color: white;
    transition: .3s ease;
    transition-property: top, bottom;
}
#header .hamburger .bar::after {
    top: 8px;
}
#header .hamburger .bar::before {
    bottom: 8px;
}
#header .hamburger.active .bar::before {
    bottom: 0;
}
#header .hamburger.active .bar::after {
    top: 0;
}
#header img{
    width: 45px;
    height: 45px;
    position: absolute;
    top: 10px;
    left: 50%;
    
    transform: translate(50px);
}
.brand img{
    width: 50px;
    height: 50px;
    color: white;
}
.opt {
    cursor: pointer;
    padding: 10px 30px;
    color: rgb(68, 66, 66);
    background-color: transparent;
    border: 2px solid rgb(27, 131, 145);
    font-size: 2rem;
    text-transform: uppercase;
    letter-spacing: .1rem;
    margin-top: 30px;
    transition: .3s ease;
    transition-property: background-color, color;
}
.opt:hover {
    color: rgb(34, 33, 33);
    background-color: rgb(135, 136, 136);
}
#hero {
    background-image: url(./C:\Users\veerendra\Desktop\v.png);
    background-size: cover;
    background-position: top center;
    position: relative;
    z-index: 1;
}
#mySidenav a {
    position: absolute;
    right: -182px;
   
    transition: 0.3s;
    padding: 15px;
    width: 220px;
    height: 50px;
    text-decoration: none;
    font-size: 20px;
    overflow-y: hidden;
    color: white;
    border-radius: 5px 0 0 5px;
  }
  
  #mySidenav a:hover {
    right: 0;
  }
  
  
  #a {
    top: 160px;
    background-color: #319c8e;
  }
  
  #b {
    top: 230px;
    background-color: #f3214f;
  }
  
  #c {
    top: 300px;
    background-color: #1deee3;
  }
  
  #d {
    top: 370px;
    background-color: rgb(55, 219, 170)
  }
  #e {
    top: 440px;
    background-color: rgb(189, 39, 109)
  }

#hero::after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 100%;
    background-color: black;
    opacity: .7;
    z-index: -1;
}
#hero .hero {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 50px;
    justify-content: flex-start;
}
#hero h1 {
    display: block;
    width: fit-content;
    font-size:30px;
    position: relative;
    color: transparent;
    animation: text_reveal .5s ease forwards;
    animation-delay: 1s;
}
#hero h1:nth-child(1) {
    animation-delay: 1s;
}
#hero h1:nth-child(2) {
    animation-delay: 2s;
}
#hero h1:nth-child(3) {
    animation: text_reveal_name .5s ease forwards;
    animation-delay: 3s;
}
#hero h1 span {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 0;
    background-color: rgba(27, 131, 145);
    animation: text_reveal_box 1s ease;
    animation-delay: .5s;
}
#hero h1:nth-child(1) span {
    animation-delay: .5s;
}
#hero h1:nth-child(2) span {
    animation-delay: 1.5s;
}
#hero h1:nth-child(3) span {
    animation-delay: 2.5s;
}


#services .services {
    flex-direction: column;
    text-align: center;
    max-width: 1500px;
    margin: 0 auto;
    padding: 100px 0;
}
#services .service-top {
    max-width: 500px;
    margin: 0 auto;
}
#services .service-bottom {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-wrap: wrap;
    margin-top: 50px;
}
#services .service-item {
    flex-basis: 80%;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    flex-direction: column;
    padding: 30px;
    border-radius: 10px;
    background-image: url("https://thumbs.gfycat.com/DevotedCarelessJackal-size_restricted.gif");
    background-size: cover;
    margin: 10px 5%;
    position: relative;
    z-index: 1;
    overflow: hidden;
}
#services .service-item::after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 100%;
    background-image: linear-gradient(60deg, #29323c 0%, #485563 100%);
    opacity: .9;
    z-index: -1;
}
#services .service-bottom .icon {
    height: 80px;
    width: 80px;
    overflow-y: hidden;
    margin-bottom: 20px;
}
#services .service-item h2 {
    font-size: 2rem;
    color: white;
    margin-bottom: 10px;
    text-transform: uppercase;
}
#services .service-item p {
    color: white;
    text-align: left;
}

#projects .projects {
    flex-direction: column;
    max-width: 1200px;
    margin: 0 auto;
    padding: 100px 0;
}
#projects .projects-header h1 {
    margin-bottom: 50px;
}
#projects .all-projects {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
}
#projects .project-item {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    width: 80%;
    margin: 20px auto;
    overflow: hidden;
    border-radius: 10px;
}
#projects .project-info {
    padding: 30px;
    flex-basis: 50%;
    height: 100%;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    flex-direction: column;
    background-image: linear-gradient(60deg, #29323c 0%, #485563 100%);
    color: white;
}
#projects .project-info h1 {
    font-size: 4rem;
    font-weight: 500;
}
#projects .project-info h2 {
    font-size: 1.8rem;
    font-weight: 500;
    margin-top: 10px;
}
#projects .project-info p {
    color: white;
}
#projects .project-img {
    flex-basis: 50%;
    height: 300px;
    overflow: hidden;
    position: relative;
}
#projects .project-img:after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 100%;
    background-image: linear-gradient(60deg, #70b8bb 0%, #a3d8db 100%);
    opacity: .7;
}
#projects .project-img img {
    transition: .3s ease transform;
}
#projects .project-item:hover .project-img img {
    transform: scale(1.1);
}
#about .about {
    flex-direction: column-reverse;
    text-align: center;
    max-width: 1200px;
    margin: 0 auto;
    padding: 100px 20px;
}
#about .col-left {
    width: 250px;
    height: 360px;
}
#about .col-right {
    width: 100%;
}
#about .col-right h2 {
    font-size: 1.8rem;
    font-weight: 500;
    letter-spacing: .2rem;
    margin-bottom: 10px;
}
#about .col-right p {
    margin-bottom: 20px;
}
#about .col-right .cta {
    color: black;
    margin-bottom: 50px;
    padding: 10px 20px;
    font-size: 2rem;
}
#about .col-left .about-img {
    height: 100%;
    width: 100%;
    position: relative;
    border: 10px solid white;
}
#about .col-left .about-img::after {
    content: '';
    position: absolute;
    left: -33px;
    top: 19px;
    height: 98%;
    width: 98%;
    border: 7px solid rgb(55, 135, 141);
    z-index: -1;
}

#contact .contact {
    
    max-width: 1200px;
    margin: 0 auto;
}
#contact .contact-items {
    width: 400px;
}
#contact .contact-item {
    width: 80%;
    padding: 20px;
    text-align: center;
    border-radius: 10px;
    padding: 30px;
    margin: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    box-shadow: 0px 0px 18px 0 #0000002c;
    transition: .3s ease box-shadow;
}
#contact .contact-item:hover {
    box-shadow: 0px 0px 5px 0 #0000002c;
}
#contact .icon {
    width: 70px;
    overflow-y: hidden;
    margin: 0 auto;
    margin-bottom: 10px;
}
#contact .contact-info h1 {
    font-size: 2.5rem;
    font-weight: 500;
    margin-bottom: 5px;
}
#contact .contact-info h2 {
    font-size: 1.3rem;
    line-height: 2rem;
    font-weight: 500;
}

#footer {
    background-image: linear-gradient(60deg, #29323c 0%, #485563 100%);
}
#footer .footer {
    min-height: 200px;
    flex-direction: column;
    padding-top: 50px;
    padding-bottom: 10px;
}
#footer h2 {
    color: white;
    font-weight: 500;
    font-size: 1.8rem;
    letter-spacing: .1rem;
    margin-top: 10px;
    margin-bottom: 10px;
}
#footer .social-icon {
    display: flex;
    
    margin-bottom: 30px;
}
#footer .social-item {
    height: 50px;
    width: 50px;
    overflow-y: hidden;
    margin: 0 5px;
}
#footer .social-item img {
    filter: grayscale(1);
    overflow-y: hidden;
    transition: .3s ease filter;
}
#footer .social-item:hover img {
    filter: grayscale(0);
}
#footer p {
    color: white;
    font-size: 1.3rem;
}
@keyframes hamburger_puls {
    0% {
        opacity: 1;
        transform: scale(1);
    }
    100% {
        opacity: 0;
        transform: scale(1.4);
    }
}
@keyframes text_reveal_box {
    50% {
        width: 100%;
        left: 0;
    }
    100% {
        width: 0;
        left: 100%;
    }
}
@keyframes text_reveal {
    100% {
        color: white;
    }
}
@keyframes text_reveal_name {
    100% {
        color: rgb(31, 133, 128);
        font-weight: 500;
    }
}

@media only screen and (min-width: 768px) {
    .cta {
        font-size: 2.5rem;
        padding: 20px 60px;
    }
    h1.section-title {
        font-size: 6rem;
    }

    
    #hero h1 {
        font-size: 7rem;
    }
    
    #services .service-bottom .service-item {
        flex-basis: 45%;
        margin: 2.5%;
    }
    
    #projects .project-item {
        flex-direction: row;
    }
    #projects .project-item:nth-child(even) {
        flex-direction: row-reverse;
    }
    #projects .project-item {
        height: 400px;
        margin: 0;
        width: 100%;
        border-radius: 0;
    }
    #projects .all-projects .project-info {
        height: 100%;
    }
    #projects .all-projects .project-img {
        height: 100%;
    }
    
    #about .about {
        flex-direction: row;
    }
    #about .col-left {
        width: 600px;
        height: 400px;
        padding-left: 60px;
    }
    #about .about .col-left .about-img::after {
        left: -45px;
        top: 34px;
        height: 98%;
        width: 98%;
        border: 10px solid rgb(43, 152, 160);
    }
    #about .col-right {
        text-align: left;
        padding: 30px;
    }
    #about .col-right h1 {
        text-align: left;
    }
    
    #contact .contact {
        flex-direction: column;
        padding: 100px 0;
        align-items: center;
        justify-content: center;
        min-width: 20vh;
    }
    #contact .contact-items {
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: space-evenly;
        margin: 0;
    }
    #contact .contact-item {
        width: 30%;
        margin: 0;
        flex-direction: row;
    }
    #contact .contact-item .icon {
        height: 100px;
        width: 100px;
    }
    #contact .contact-item .icon img {
        object-fit: contain;
    }
    #contact .contact-item .contact-info {
        width: 100%;
        text-align: left;
        padding-left: 20px;
    }
    
@media only screen and (min-width: 1200px) {
    
    #header .hamburger {
        display: none;
    }
    #header .nav-list ul {
        position: initial;
        display: block;
        height: auto;
        width: fit-content;
        background-color: transparent;
    }
    #header .nav-list ul li {
        display: inline-block;
    }
    #header .nav-list ul li a {
        font-size: 1.8rem;
    }
    #header .nav-list ul a:after {
        display: none;
    }
    

    #services .service-bottom .service-item {
        flex-basis: 22%;
        margin: 1.5%;
    }
}
.like-content {
    display: inline-block;
    width: 100%;
    margin: 40px 0 0;
    padding: 40px 0 0;
    font-size: 18px;
    border-top: 10px dashed #eee;
    text-align: center;
}
.like-content span {
    color: #9d9da4;
    font-family: monospace;
}
.like-content .btn-secondary {
      display: block;
      margin: 40px auto 0px;
    text-align: center;
    background: #ed2553;
    border-radius: 3px;
    box-shadow: 0 10px 20px -8px rgb(240, 75, 113);
    padding: 10px 17px;
    font-size: 18px;
    cursor: pointer;
    border: none;
    outline: none;
    color: #ffffff;
    text-decoration: none;
    -webkit-transition: 0.3s ease;
    transition: 0.3s ease;
}
.like-content .btn-secondary:hover {
      transform: translateY(-3px);
}
.like-content .btn-secondary .fa {
      margin-right: 5px;
}
.animate-like {
    animation-name: likeAnimation;
    animation-iteration-count: 1;
    animation-fill-mode: forwards;
    animation-duration: 0.65s;
}
@keyframes likeAnimation {
  0%   { transform: scale(30); }
  100% { transform: scale(1); }
}
@import url(https://fonts.googleapis.com/css?family=Open+Sans);
.search {
    width: 100%;
    position: relative;
    display: flex;
  }
  
  .searchTerm {
    width: 5000px;
    border: 2px solid black;
    border-right: none;
    padding: 5px;
    height: 40px;
    border-radius: 5px 0 0 5px;
    outline: none;
    color: #9DBFAF;
  }
  .searchTerm:focus{
    color: #0a0c0c;
  }
  
  .searchButton {
    width: 800px;
    height: 40px;
    border: 2px solid black;
    background: black;
    opacity:.6;
    text-align: center;
    color: #fff;
    border-radius: 0 5px 5px 0;
    cursor: pointer;
    outline: none;
    font-size: 20px;
  }
  .searchButton i{
      margin-top: 9px;
  }
  .wrap{
    width: 30%;
    position: absolute;
    top: 15%;
    left: 49%;
    transform: translate(-50%, -50%);
  }
  .font{
    font-size: 30px;
    color: black;
    opacity:1;
  }
  .one{
    border: 2px solid black;
    width: 1050px;
    height :absolute;
    margin-top: 9%;
    margin-left: 17%;
    opacity:1;
    overflow-y: hidden;
    border-radius: 20px;
   background-color: white;
   color:black;
}
.two{
    border: 2px solid rgb(107, 109, 109);
    width: 1050px;
    height: 170px;
    margin-top: 5%;
    margin-left: 12%;
    overflow-y: hidden;
}
.three{
    border: 2px solid rgb(107, 109, 109);
    width: 1050px;
    height: 170px;
    margin-top: 5%;
    margin-left: 12%;
    overflow-y: hidden;
}
.four{
    border: 2px solid rgb(107, 109, 109);
    width: 1050px;
    height: 170px;
    margin-top: 5%;
    margin-left: 12%;
    overflow-y: hidden;
}
.five{
    border: 2px solid rgb(107, 109, 109);
    width: 1050px;
    height: 170px;
    margin-top: 5%;
    margin-left: 12%;
    overflow-y: hidden;
}
.content{
    padding:  5px 18px;
    line-height: 1.8;
    
  
}
.line{
    width: 300px;
    height: 2px;
    background-color: #485563;
}
.content p{
  color: #043036;
  font-weight: bold;
}
.iconify{
  font-size: 15px;
}
.heading {
  font-size: 18px;
  margin-top: 0px;
  

}
.loc{
    margin-top: 10px;
}

.fa {
  font-size: 15px;

}
.button{
    display: inline-block;
    margin-left: 850px;
    margin-top: -25px;
}
.button button{
    margin-left: 20px;
}
.button1,.button2,.button3{
    
      font-family: "trebuchet ms";
      font-weight: bold;
      
      padding: 9px 16px;
      border: 1px solid rgb(51, 143, 143);
      background-color: #29323c;
      transition: 0.5s;
      color: rgb(43, 233, 223);
      outline: none;
  }
  .button1:hover,.button2:hover,.button3:hover{
    
      color: #fff;
  }
}

body {
  /* background: linear-gradient(-45deg, #ee7752, #e079cf, #23d5ab);*/
    background-size: 400% 400%;
   /* animation: gradient 15s ease infinite;*/
}

@keyframes gradient {
    0% {
        background-position: 0% 50%;
    }
    50% {
        background-position: 100% 50%;
    }
    100% {
        background-position: 0% 50%;
    }
}
</style>
</head>
<body>
<script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>



<div>

         <?php
         include 'o1.php';
         $oid=$_POST["orphnageid"];
         ?>



<form action="#" method="post">
<section>
<div id="list">

 <section id="header">
 <div class="header container">
 <div class="nav-bar">
 <div class="brand">
   
 <a href="#hero"><h1 style="font-size:40px;"><span>O</span>rphan <span>C</span>onnect</h1></a>
 </div>
 <div class="nav-list">
 <div class="hamburger"><div class="bar"></div></div>
 <ul>
 
 <li><a href="home.html" data-after="hero"><h1 style="font-size:32px;">HOME</h1> </a></li>
<li><a href="orphanmain.php"><h1 style="font-size:32px;">MY PROFILE</h1></a></li>

 </ul>
 </div>
 </div>
 </div>
 </section>
 <br>
<div align="center" class="wrap">
<br><br><br><br><br><br>
<h1 style="color:white;font-size:25px">Please inform the conformation details to donars personally</h1>

</div>
<br><br><br><br><br><br><br><br>
<?php

$q4=mysqli_query($conn,"select *  from `tbl_medical_volunteer` where `MV_orphanages`='$oid' order by `MV_Resgistration_time` desc ");
if($q4->num_rows > 0)
{?>
<div class="one">
<div class="content">  
<h1><div class="font">Medical Volunteer</div></h1>
           <div class="line"></div>
               
<?php
while( $row4 = $q4->fetch_object()){
    $n3=$row4->MV_Region;
    $c3=$row4->MV_Name;
    $aa3=$row4->MV_Name_Of_Institute;
    $g3=$row4->MV_Email;
    $s3=$row4->MV_Phone_number;
    $e3=$row4->MV_Institute_Address;
    $p3=$row4->MV_city;
    $pn3=$row4->MV_State;
    $l3=$row4->MV_Pincode;
    $b3=$row4->MV_No_of_persons;
?>

          
           
           <p>Region
            (1=Hospital 2=Medical College)  :  
            <?=$n3?><br>
            Name : 
            <?=$c3?><br>
            Name Of Institute:
            <?=$aa3?><br>
            Email_id:
            <?=$g3?><br>
            Phone Number:
            <?=$s3?><br>
            NO of Persons in Volunteering Group : 
            <?=$b3?><br>
            <div class="loc"><span class="iconify" data-icon="si-glyph:pin-location-2" data-inline="false"></span>
               <span class="heading" name="loc1">
            Address:
            <?=$e3?>&nbsp;&nbsp;&nbsp;
            City:
            <?=$p3?>&nbsp;&nbsp;&nbsp;
            State:
            <?=$pn3?>&nbsp;&nbsp;&nbsp;
            Pin code:
            <?=$l3?>
            </span></a>
           </div><br><br>

            <?php
}}?>
 </div>
 </div> 

 <?php

$q5=mysqli_query($conn,"select *  from `formal_volunteer` where `Orphanage`='$oid' order by `Registered_time` desc ");
if($q5->num_rows > 0)
{?>
<div class="one">
<div class="content">  
<h1><div class="font">Formal Volunteer</div></h1>
           <div class="line"></div>
               
<?php
while( $row5 = $q5->fetch_object()){
    $n4=$row5->First_Name;
    $c4=$row5->Last_Name;
    $aa4=$row5->Age;
    $g4=$row5->Email;
    $s4=$row5->Phone;
    $e4=$row5->Address;
    $p4=$row5->City_or_District;
   $pn4=$row5->State;
    $l4=$row5->PINCODE;
    $b4=$row5->Number_of_persons_interested_in_Volunteering;
?>

          
           
           <p>First Name :  
            <?=$n4?><br>
            Last Name : 
            <?=$c4?><br>
            Age : 
            <?=$aa4?><br>
            Email_id:
            <?=$g4?><br>
            Phone Number:
            <?=$s4?><br>
            No Of persons in Volunteering Group: 
            <?=$b4?><br>
            <div class="loc"><span class="iconify" data-icon="si-glyph:pin-location-2" data-inline="false"></span>
               <span class="heading" name="loc1">
            Address:
            <?=$e4?>&nbsp;&nbsp;&nbsp;
            City:
            <?=$p4?>&nbsp;&nbsp;&nbsp;
            State:
            <?=$pn4?>&nbsp;&nbsp;&nbsp;
            Pin code:
            <?=$l4?>
            </span></a>
           </div><br><br>

            <?php
}}?>
 </div>
 </div> 
 
 <?php

$q6=mysqli_query($conn,"select *  from `money` where `Orphanage`='$oid' order by `Donated_time` desc ");
if($q6->num_rows > 0)
{?>
<div class="one">
<div class="content">  
<h1><div class="font">Funding</div></h1>
           <div class="line"></div>
               
<?php
while( $row6 = $q6->fetch_object()){
    $n6=$row6->First_Name;
    $c6=$row6->Last_Name;
    $g6=$row6->Email;
    $s6=$row6->Phone;
    $aa6=$row6->Mode_of_Transfer;
    $e6=$row6->Address;
    $p6=$row6->City_or_District;
   $pn6=$row6->State;
    $l6=$row6->PINCODE;
    $b6=$row6->Transaction_ID;
?>

          
           
           <p>First Name :  
            <?=$n6?><br>
            Last Name : 
            <?=$c6?><br>
            Email_id:
            <?=$g6?><br>
            Phone Number:
            <?=$s6?><br>
            Mode Of Transfer:
            <?=$aa6?><br>
            Transaction ID : 
            <?=$b6?><br>
            <div class="loc"><span class="iconify" data-icon="si-glyph:pin-location-2" data-inline="false"></span>
               <span class="heading" name="loc1">
            Address:
            <?=$e6?>&nbsp;&nbsp;&nbsp;
            City:
            <?=$p6?>&nbsp;&nbsp;&nbsp;
            State:
            <?=$pn6?>&nbsp;&nbsp;&nbsp;
            Pin code:
            <?=$l6?>
            </span></a>
           </div><br><br>

            <?php
}}?>
 </div>
 </div> 

<?php

$q1=mysqli_query($conn,"select *  from `clothes` where `Orphanage`='$oid' order by `Donated_time` Desc");

if($q1->num_rows > 0)
{?>
<div class="one">
<div class="content">

          
<h1><div class="font">CLOTHES</div></h1>
           <div class="line"></div>
<?php
while( $row1 = $q1->fetch_object()){
    $n=$row1->First_Name;
    $c=$row1->Last_Name;
    $g=$row1->Email;
    $s=$row1->Phone;
    $e=$row1->Address;
    $p=$row1->City;
    $pn=$row1->State;
    $l=$row1->PINCODE;
    $b=$row1->Transaction_ID;
    ?>
  
           
           <p>First Name :  
            <?=$n?><br>
            Last Name : 
            <?=$c?><br>
            Email_id:
            <?=$g?><br>
            Phone Number:
            <?=$s?><br>
            Transaction ID : 
            <?=$b?><br>
            <div class="loc"><span class="iconify" data-icon="si-glyph:pin-location-2" data-inline="false"></span>
               <span class="heading" name="loc1">
               Address:
            <?=$e?>&nbsp;&nbsp;&nbsp;
            City:
            <?=$p?>&nbsp;&nbsp;&nbsp;
            State:
            <?=$pn?>&nbsp;&nbsp;&nbsp;
            Pin code:
            <?=$l?>
               </span></a>
           </div><br><br>
            
            
<?php
}}?>
 </div>
 </div>           



<?php

$q2=mysqli_query($conn,"select *  from `appliances` where `Orphanage`='$oid' order by `Donated_time` desc ");
if($q2->num_rows > 0)
{?>
<div class="one">
<div class="content">  
<h1><div class="font">Appliances</div></h1>
           <div class="line"></div>
               
<?php
while( $row2 = $q2->fetch_object()){
    $n1=$row2->First_Name;
    $c1=$row2->Last_Name;
    $g1=$row2->Email;
    $s1=$row2->Phone;
    $e1=$row2->Address;
    $p1=$row2->City_or_District;
    $pn1=$row2->Village;
    $l1=$row2->PINCODE;
    $b1=$row2->Transaction_ID;
?>

          
           
           <p>First Name :  
            <?=$n1?><br>
            Last Name : 
            <?=$c1?><br>
            Email_id:
            <?=$g1?><br>
            Phone Number:
            <?=$s1?><br>
            Transaction ID : 
            <?=$b1?><br>
            <div class="loc"><span class="iconify" data-icon="si-glyph:pin-location-2" data-inline="false"></span>
               <span class="heading" name="loc1">
            Address:
            <?=$e1?>&nbsp;&nbsp;&nbsp;
            City:
            <?=$p1?>&nbsp;&nbsp;&nbsp;
            State:
            <?=$pn1?>&nbsp;&nbsp;&nbsp;
            Pin code:
            <?=$l1?>
            </span></a>
           </div><br><br>

            <?php
}}?>
 </div>
 </div>           
      

<?php


$q3=mysqli_query($conn,"select *  from `books` where `Orphanage`='$oid' order by `Donated_time` desc ");
if($q3->num_rows > 0)
{?>

<div class="one">
<div class="content">  
<h1><div class="font">Books</div></h1>
           <div class="line"></div>   
<?Php
while( $row3 = $q3->fetch_object()){
    $n2=$row3->First_Name;
    $c2=$row3->Last_Name;
    $g2=$row3->Email;
    $s2=$row3->Phone;
    $e2=$row3->Address;
    $p2=$row3->City_or_District;
    $pn2=$row3->Village;
    $l2=$row3->PINCODE;
    $b2=$row3->Transaction_ID;
?>

          
           
           
           <p>First Name :  
            <?=$n2?><br>
            Last Name : 
            <?=$c2?><br>
            Email_id:
            <?=$g2?><br>
            Phone Number:
            <?=$s2?><br>
            Transaction ID : 
            <?=$b2?><br>
            <div class="loc"><span class="iconify" data-icon="si-glyph:pin-location-2" data-inline="false"></span>
               <span class="heading" name="loc1">
            Address:
            <?=$e2?>&nbsp;&nbsp;&nbsp;
            City:
            <?=$p2?>&nbsp;&nbsp;&nbsp;
            State:
            <?=$pn2?>&nbsp;&nbsp;&nbsp;
            Pin code:
            <?=$l2?>
            </span></a>
           </div><br><br>
       

            <?php
}}
?>
 </div>
 </div>
 <?php

$q7=mysqli_query($conn,"select *  from `groceries` where `Orphanage`='$oid' order by `Donated_time` desc ");
if($q7->num_rows > 0)
{?>
<div class="one">
<div class="content">  
<h1><div class="font">Groceries</div></h1>
           <div class="line"></div>
               
<?php
while( $row7 = $q7->fetch_object()){
    $n7=$row7->First_Name;
    $c7=$row7->Last_Name;
    $g7=$row7->Email;
    $s7=$row7->Phone;
    $e7=$row7->Address;
    $p7=$row7->city;
   $pn7=$row7->state;
    $l7=$row7->PINCODE;
    $b7=$row7->Transaction_ID;
?>

          
           
           <p>First Name :  
            <?=$n7?><br>
            Last Name : 
            <?=$c7?><br>
            Email_id:
            <?=$g7?><br>
            Phone Number:
            <?=$s7?><br>
            Transaction ID : 
            <?=$b7?><br>
            <div class="loc"><span class="iconify" data-icon="si-glyph:pin-location-2" data-inline="false"></span>
               <span class="heading" name="loc1">
            Address:
            <?=$e7?>&nbsp;&nbsp;&nbsp;
            City:
            <?=$p7?>&nbsp;&nbsp;&nbsp;
            State:
            <?=$pn7?>&nbsp;&nbsp;&nbsp;
            Pin code:
            <?=$l7?>
            </span></a>
           </div><br><br>

            <?php
}}?>
 </div>
 </div>  

 <?php

$q8=mysqli_query($conn,"select *  from `toys` where `Orphanage`='$oid' order by `T_Order_time` desc ");
if($q8->num_rows > 0)
{?>
<div class="one">
<div class="content">  
<h1><div class="font">Toys</div></h1>
           <div class="line"></div>
               
<?php
while( $row8 = $q8->fetch_object()){
    $n8=$row8->First_Name;
    $c8=$row8->Last_Name;
    $g8=$row8->Email;
    $s8=$row8->Phone;
    $e8=$row8->Address;
    $p8=$row8->City_or_District;
   $pn8=$row8->Village;
    $l8=$row8->PINCODE;
    $b8=$row8->Transaction_ID;
?>

          
           
           <p>First Name :  
            <?=$n8?><br>
            Last Name : 
            <?=$c8?><br>
            Email_id:
            <?=$g8?><br>
            Phone Number:
            <?=$s8?><br>
            Transaction ID : 
            <?=$b8?><br>
            <div class="loc"><span class="iconify" data-icon="si-glyph:pin-location-2" data-inline="false"></span>
               <span class="heading" name="loc1">
            Address:
            <?=$e8?>&nbsp;&nbsp;&nbsp;
            City:
            <?=$p8?>&nbsp;&nbsp;&nbsp;
            State:
            <?=$pn8?>&nbsp;&nbsp;&nbsp;
            Pin code:
            <?=$l8?>
            </span></a>
           </div><br><br>

            <?php
}}?>
 </div>
 </div> 

 <?php

$q9=mysqli_query($conn,"select *  from `furniture` where `Orphanage`='$oid' order by `Donated_time` desc ");
if($q9->num_rows > 0)
{?>
<div class="one">
<div class="content">  
<h1><div class="font">Furniture</div></h1>
           <div class="line"></div>
               
<?php
while( $row9 = $q9->fetch_object()){
    $n9=$row9->First_Name;
    $c9=$row9->Last_Name;
    $g9=$row9->Email;
    $s9=$row9->Phone;
    $e9=$row9->Address;
    $p9=$row9->City_or_District;
   $pn9=$row9->Village;
    $l9=$row9->PINCODE;
    $b9=$row9->Transaction_ID;
?>

          
           
           <p>First Name :  
            <?=$n9?><br>
            Last Name : 
            <?=$c9?><br>
            Email_id:
            <?=$g9?><br>
            Phone Number:
            <?=$s9?><br>
            Transaction ID : 
            <?=$b9?><br>
            <div class="loc"><span class="iconify" data-icon="si-glyph:pin-location-2" data-inline="false"></span>
               <span class="heading" name="loc1">
            Address:
            <?=$e9?>&nbsp;&nbsp;&nbsp;
            City:
            <?=$p9?>&nbsp;&nbsp;&nbsp;
            State:
            <?=$pn9?>&nbsp;&nbsp;&nbsp;
            Pin code:
            <?=$l9?>
            </span></a>
           </div><br><br>

            <?php
}}?>
 </div>
 </div> 

</div>           
</div>  
</form>
</body>
</html>
