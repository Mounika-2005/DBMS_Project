<!DOCTYPE html>
<html>
<head>
 <title>books</title>
 <link rel="stylesheet" href="Grocery1.css">
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
  *{
margin: 0;
padding: 0;
}
body{
background-image: url("https://thumbs.dreamstime.com/b/happy-kids-carry-donate-books-boys-clip-art-girls-preschool-kindergarten-pupil-painting-read-charity-elementary-library-classroom-158023417.jpg");
background-position: center;
background-size: cover;
font-family: Trebuchet MS;
margin-top: 40px;
}
/*img{
        width: 125px;
        height: 125px;
        ;
    }*/
.regform{
width: 800px;
background-color: rgba(0,0,0,0.6);
margin: auto;
color: #FFFFFF;
padding: 10px 0px 10px 0px;
text-align: center;
border-radius: 15px 15px 0px 0px;
}
.main{
background-color: rgba(0,0,0,0.5);
width: 800px;
margin: auto;
}
form{
padding: 10px;
}
#name{
width: 100%;
height: 100px;
}
.name{
margin-left: 25px;
margin-top: 30px;
width: 125px;
color: white;
font-size: 18px;
font-weight: 700;
}
.firstname{
position: relative;
left: 150px;
top: -37px;
line-height: 40px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
}
.lastname{
position: relative;
left: 417px;
top: -80px;
line-height: 40px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
}
.firstlabel{
position: relative;
left: 155px;
top: -45px;
font-size: 14px;
color: #E5E5E5;
text-transform: capitalize;
}
.lastlabel{
position: relative;
left: 175px;
top: -45px;
font-size: 14px;
color: #E5E5E5;
text-transform: capitalize;
}
.option1{
position: relative;
left: 200px;
top: -37px;
line-height: 40px;
width: 532px;
height: 40px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
outline: none;
overflow: hidden;
}
.option1 option{
font-size: 20px;
}
.email{
position: relative;
left: 200px;
top: -37px;
line-height: 40px;
width: 480px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
}

.number{
position: relative;
left: 200px;
top: -37px;
line-height: 40px;
width: 255px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
}
.area-code{
position: relative;
color: #E5E5E5;
text-transform: capitalize;
font-size: 16px;
left: 54px;
top: -4px;
}
.phone-number{
position: relative;
color: #E5E5E5;
text-transform: capitalize;
font-size: 16px;
left: -100px;
top: -2px;
}
#customer{
margin-left: 25px;
color: white;
font-size: 18px;
}
.radio1{
display: inline-block;
padding-right: 70px;
font-size: 25px;
margin-left: 25px;
margin-top: 15px;
color: white;
}
.radio1 input{
width: 20px;
height: 20px;
cursor: pointer;
border-radius: 50%;
outline: none;
}
.Address{
position: relative;
left: 200px;
top: -37px;
line-height: 40px;
width: 480px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
}
.city{
position: relative;
left: 200px;
top: -37px;
line-height: 40px;
width: 480px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
}
.state{
position: relative;
left: 200px;
top: -37px;
line-height: 40px;
width: 480px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
}
.pin{
position: relative;
left: 200px;
top: -37px;
line-height: 40px;
width: 140px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
}
.weight{
position: relative;
left: 200px;
top: -37px;
line-height: 40px;
width: 480px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
}
.button{
background-color: #3BAF9F;
display: block;
margin: 60px 0px 0px 250px;
text-align: center;
border-radius: 12px;
border: 2px solid #366473;
padding: 14px 110px;
outline: none;
color: white;
cursor: pointer;
transition: 0.25px;
}
.age{
position: relative;
left: 200px;
top: -37px;
line-height: 40px;
width: 132px;
height: 40px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
outline: none;
overflow: hidden;
}
.age option{
font-size: 20px;
}
.fa{
position: relative;
left: 198px;
top: -37px;
line-height: 40px;
width: 5px;
height: 45px;
text-align: center;
border-radius: 56px;
padding: 0 22px;
font-size: 46px;
margin: 15px;
color: #555;
}
.pics{
display: inline-block;
position: relative;
}
.container {
  padding: 32px;
  transform: translate(150px, -60px);
}

.select-box {
  position: relative;
  display: flex;
  width: 400px;
  flex-direction: column;
}

.select-box .options-container {
  background: #455466;
  color: #f5f6fa;
  max-height: 0;
  width: 100%;
  opacity: 0;
  transition: all 0.4s;
  border-radius: 8px;
  overflow: hidden;

  order: 1;

  position: absolute;
  z-index: 100;
}

.selected {
  background: #FFFFFF;
  border-radius: 8px;
  margin-bottom: 8px;
  color: #2c2e33;
  position: relative;

  order: 0;
}

.selected::after {
  content: "";
  background: url("https://upload.wikimedia.org/wikipedia/commons/9/9d/Arrow-down.svg");
  background-size: contain;
  background-repeat: no-repeat;

  position: absolute;
  height: 100%;
  width: 32px;
  right: 9px;
  top: 13px;

  transition: all 0.4s;
}

.select-box .options-container.active {
  max-height: 100px;
  opacity: 1;
  overflow-y: scroll;
  margin-top: 104px;
}

.select-box .options-container.active + .selected::after {
  transform: rotateX(180deg);
  top: -6px;
}

.select-box .options-container::-webkit-scrollbar {
  width: 8px;
  background: #0d141f;
  border-radius: 0 8px 8px 0;
}

.select-box .options-container::-webkit-scrollbar-thumb {
  background: #525861;
  border-radius: 0 8px 8px 0;
}

.select-box .option,.selected {
  padding: 12px 24px;
  cursor: pointer;
}

.select-box .option:hover {
  background: #414b57;
}

.select-box label {
  cursor: pointer;
}

.select-box .option .radio {
  display: none;
}


.search-box input {
  width: 88%;
  padding: 12px 16px;
  font-family: "Roboto", sans-serif;
  font-size: 16px;
  position: absolute;
  border-radius: 8px 8px 0 0;
  z-index: 100;
  border: 8px solid #2f3640;

  opacity: 0;
  pointer-events: none;
  transition: all 0.4s;
}

.search-box input:focus {
  outline: none;
}

.select-box .options-container.active ~ .search-box input {
  opacity: 1;
  pointer-events: auto;
}
.transaction{
position: relative;
left: 200px;
top: -37px;
line-height: 40px;
width: 140px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
outline: none;
}

a:link, a:visited {
 
 background-color: white;
 color: black;
 border: 2px solid white;
 padding: 10px 20px;
 text-align: center;
 left:200px;
 text-decoration: none;
 display: inline-block;
 font-size: 16px;
}

a:hover, a:active {
 background-color: black;
 color: white;
}

.link-container {
   display:block;
   margin: auto;
   
}
.buttonCls{
       border-radius: 10px;
       width:200px;
       height: 25px;
       background-color:#003366;
       color:white;
       opacity: 0.5;
       font-size:18px;
    }

</style>
<body>

<div>
<?php

if(array_key_exists('submit', $_POST)) 
    { 
      SaveBooksDetails(); 
    }
  function SaveBooksDetails()
    {
      $conn=mysqli_connect('localhost','root','','donation');
      if (!$conn) 
      {
        die("Connection failed: " . 
        mysqli_connect_error());
      }
      ?>
    <div class="regform"><h1>Thank you<br><br></h1>
	<h2>Your responce has been recorded<br></h2></div>
	<div align="center">
	<br>
	<a href="donation.html"><div class="buttoncls">DONATE MORE..</div></a>&emsp;&emsp;&emsp;&emsp;<a href="home.html"><div class="buttoncls">HOME</div></a>
	</div>

   <?php

      if($_POST['first_name']!="")
      {
        $firstname = $_POST['first_name'];
        $lastname = $_POST['last_name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $address = $_POST['Address'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $pin = $_POST['pin'];
        $transactonid = $_POST['Transaction_ID'];
        $No_of_Books = $_POST['No_books'];
        $orphanage = $_POST['Orphanselect'];
        mysqli_query($conn, "INSERT INTO books(`First_Name`, `Last_Name`, `Email`, `Phone`, `Address`, 
        `City_or_District`, `Village`, `PINCODE`, `Transaction_ID`, `Number_of_Books`, `Orphanage`)
        VALUES('$firstname' ,'$lastname','$email','$phone','$address','$city','$state',
        '$pin','$transactonid','$No_of_Books','$orphanage')");
         exit;
       }
      else 
      {
        echo '<script> alert("Please Fill all your details")</script>';
      }
    }     
    ?>

<?php
$con= mysqli_connect('localhost','root','','orphanage_');
$s= mysqli_query($con,"SELECT * FROM `orphanage_details`")

?>
</div>
<div class="regform"><h1>Details for books donation</h1></div>
<div class="main">
<form action="" method ="post">
<div id="name">
<h2 class="name">Name</h2>
<input class="firstname" type="text" name="first_name" pattern="[a-zA-Z-' ]{1,}"><br>
<label class="firstlabel">first name</label>
<input class="lastname" type="text" name="last_name" pattern="[a-zA-Z-' ]{1,}">
<label class="lastlabel">last name</label>
</div>

<h2 class="name">Email</h2>
<input class="email" type="text" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}">

<h2 class="name"> Phone</h2>
<input class="number" type="text" name="phone" pattern="[6-9]{1}[0-9{9}">
<label class="phone-number">Phone Number</label>

<h2 id="customer">Gender</h2>
<div class="radio1">
<input class="radio1" type="radio"  name="gender" value="Male">
Male
<input class="radio1" type="radio" name="gender" value="Female">
Female
<input class="radio1" type="radio" name="gender" value="Others">
Others
</div>
<br><br>
<h2 class="name"> Address</h2>
<input class="Address" type="text" name="Address">
 
<h2 class="name"> city/district</h2>
<input class="city" type="text" name="city">

<h2 class="name"> state</h2>
<input class="state" type="text" name="state" pattern="[a-zA-Z-' ]{1,}">

<h2 class="name"> Pin</h2>
<input class="pin" type="text" name="pin" pattern="\d{4}|\d{6}">

<h2 class="name">Orphanages</h2>

<div id="myDropdown" class="options-container">
<select class="option1" name ="Orphanselect">
<option>--choose orphanage--</option>
<?php

 while($r= mysqli_fetch_array($s))
 {
   ?>
<option value="<?php echo $r['orphanage_id']; ?>"><?php echo $r['orphanage_name']; ?></option>
<?php
 }
?>
</select>
<h2 class="name">Orphanage Address</h2>
<div class="link container">
<a href="orphanage_details.php" target="_blank">Address</a>
</div>

<h2 class="name">*Shop online*</h2>
<div class="link container">
<a href="https://www.snapdeal.com/products/books#bcrumbLabelId:372" target="_blank">shop online(for all themes)</a>

</div>
<h2 class="name"> Transaction ID</h2>
<input class="transaction" type="text" name="Transaction_ID" pattern="[A-Z]{2}\d{6}\d{4}" required>


     
<h2 class="name">Number of books</h2>
<input class="transaction" type="text" name="No_books" placeholder="--In numbers--"><br><br>
<br>
<input type="submit"  value="Submit" name="submit" class="button" >


</form>
 
<script src="clothes.js"></script>
</form>
</body>
</html>
