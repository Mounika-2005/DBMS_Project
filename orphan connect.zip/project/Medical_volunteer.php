<!DOCTYPE html>
<html>
 <!-- <div> <h3 class="In"> Instructions </h3><br>
       <h4 class="In"> 1.The Volunteer Must be above 18 years</h4><br>
        <h4 class="In">2.</h4><br>
       <h4 class="In"> 3.</h4><br>
  </div>-->
<head>
 <title>Mediacal Volunteer</title>
<link rel="stylesheet" href="Medical_volunteer.css"> 
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 
 <style>
 .buttonCls{
       border-radius: 10px;
       width:200px;
       height: 25px;
       background-color:#003366;
       color:white;
       opacity: 0.5;
       font-size:18px;
    }
	.button{
background-color: #3BAF9F;
display: block;
margin: 60px 0px 0px 250px;
text-align: center;
border-radius: 12px;
border: 2px solid #366473;
padding: 14px 110px;
outline: none;
color: white;
cursor: pointer;
transition: 0.25px;
}
 </style>
</head>

<body>

<div>
 <?php

 
 if(array_key_exists('submit', $_POST)) { 
   SaveMVDetails(); 
 }
 function SaveMVDetails()
  { 
  $conn=mysqli_connect('localhost','root','','donation');
   if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
    }
   
   ?>
    <div class="regform"><h1>Thank you<br><br></h1>
	<h2>Orphanage will shortly contact you<br></h2></div>
	<div align="center">
	<br>
	<a href="donation.html"><div class="buttoncls">DONATE MORE..</div></a>&emsp;&emsp;&emsp;&emsp;<a href="home.html"><div class="buttoncls">HOME</div></a>
	</div>

   <?php
   
    IF($_POST['Tname']!='')
      { 
       $Region=$_POST['ttype'];
       $Name=$_POST['Tname'];
       $Institute_Name=$_POST['Iname'];
       $Email_id=$_POST['email'];
        $Phone_number=$_POST['phone'];
        $Address=$_POST['Address'];
       $City=$_POST['city'];
        $State=$_POST['state'];
        $Pin_code=$_POST['pin'];
        $No_of_persons=$_POST['persons'];
        $Orphanage_select=$_POST['Orphanselect'];

        mysqli_query($conn,"INSERT INTO Tbl_Medical_Volunteer (MV_Region,
               MV_Name,
             MV_Name_Of_Institute,
             MV_Email,
             MV_Phone_number,
              MV_Institute_Address,
             MV_city,
              MV_State,
               MV_Pincode,
             MV_No_of_persons, MV_orphanages)
            Values ('$Region','$Name', '$Institute_Name', '$Email_id' ,'$Phone_number', '$Address', '$City',
              '$State' , '$Pin_code' ,'$No_of_persons', '$Orphanage_select')");
 /*echo '<script>alert("Form Submitted Successfully..!!")</script>';*/
 exit;

      }
      else
      {
         echo '<script>alert("Please Enter Name.")</script>';
      }
  }

?>
<?php
$con= mysqli_connect('localhost','root','','orphanage_');
$s= mysqli_query($con,"SELECT * FROM `orphanage_details`")

?>
</div>

<div class="regform"><h1>Medical Volunteer</h1></div>
<div class="main">
<form action="" method="POST">
 <br> <br>
<div class="check">
<input class="radio1" type="radio" value="1" name="ttype"> Hospital 
<input class="radio1" type="radio" value="1" name="ttype"> Medical collage 
    
</div>
<br> <br>
<div id="name">
<h2 class="name">Name of Team</h2>
<input class="Tname" type="text" name="Tname" pattern="[a-zA-Z-' ]{1,}"><br>

<h2 class="name">Name of Institute</h2>
<input class="Iname" type="text" name="Iname" pattern="[a-zA-Z-' ]{1,}"><br>

<h2 class="name">Email</h2>
<input class="email" type="text" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}">

<h2 class="name"> Phone</h2>
<input class="number" type="text" name="phone" pattern="[6-9]{1}[0-9]{9}">


<h2 class="name"> Institute Address</h2>
<input class="Address" type="text" name="Address">
 
<h2 class="name"> city/district</h2>
<input class="city" type="text" name="city">

<h2 class="name"> State</h2>
<input class="state" type="text" name="state" pattern="[a-zA-Z-' ]{1,}">

<h2 class="name"> Pin Code</h2>
<input class="pin" type="text" name="pin" pattern="\d{4}|\d{6}">

<h2 class="name">No Of persons in team</h2>
<input class="persons" type="number" name="persons" min=1 > 

<h2 class="name">Orphanage Address</h2>
<div class="link container">
<a href="orphanage_details.php" target="_blank">Address</a>
</div>

<h2 class="name">Orphanages</h2>
<div id="myDropdown" class="options-container">
<select class="option1" name ="Orphanselect">
<option>--choose orphanage--</option>
<?php

 while($r= mysqli_fetch_array($s))
 {
   ?>
<option value="<?php echo $r['orphanage_id']; ?>"><?php echo $r['orphanage_name']; ?></option>
<?php
 }
?>

</select>

</div>


<br>
  <!--<button type="submit" name="submit">Submit</button> -->
<input type="submit"  value="Register" name="submit" class="button" >
<!--</form>
 
<script src="groceries.js"></script>

<button type="submit">Submit</button>-->
</form>

</body>
</html>