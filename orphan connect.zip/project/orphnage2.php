
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="home_.css">
 <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
 <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="new.js" type="text/javascript"></script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 <title>My Website</title>
</head>
<style>
 .button{
        font-family:'Trebuchet MS';
       border-radius: 10px;
       width: 150px;
       height: 25px;
       background-color:#319c8e;
       color:white;
       opacity: 0.7;
       text-align:center;
       font-size:18px;
    }
</style>
<body>

 <section id="header">
 <div class="header container">
 <div class="nav-bar">
 <div class="brand">
   
 <a href="#hero"><h1><span>O</span>rphan <span>C</span>onnect</h1></a>
 </div>
 <div class="nav-list">
 <div class="hamburger"><div class="bar"></div></div>
 <ul>
 
 <li><a href="home.html" data-after="hero">HOME </a></li>
<li><a href="search2.php">ORPHANAGE DETAILS</a></li>
<li><a href="orphanmain.php">MY PROFILE</a></li>

 </ul>
 </div>
 </div>
 </div>
 
</body>
 </section>

 
 <section id="hero">
 
 <form method="post" action="orphnage3.php">
 <div class="hero container">

<h1 style="align:center;font-size:30px;font-family:Trebuchet MS;font-color:white">ENTER ORPHNAGE ID:</h1>
<input type="text" name="orphnageid">&emsp;&emsp;
<input type="submit"  value="SUBMIT" name="submit" class="button" >
    
<!--<input type="submit">-->
 
 </div>
 </form>
 
 </section>
 
 


 
 <script src="./new.js"></script>
</body>
</html>