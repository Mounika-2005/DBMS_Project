<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="Orphanage Enrollment.css">
 <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<style>
 .regform{
        font-family:'Trebuchet MS';
        width: 1000px;
        background-color: rgba(46, 43, 43, 0.8);
        margin: auto;
        color: #FFFFFF;
        padding: 10px 0px 10px 0px;
        text-align: center;
        border-radius: 15px 15px 0px 0px;
        font-size:25px;
}
.regform1{
        font-family:'Trebuchet MS';
        width: 1000px;
        background-color: rgba(46, 43, 43, 0.8);
        margin: auto;
        color: #FFFFFF;
        text-align: center;
        border-radius:0px 0px 0px 0px;
        font-size:20px;
}
.main{
background-color: #555;
opacity: 0.8;
font-family:'Trebuchet MS';
width: 1000px;
margin: auto;
color: #FFFFFF;
}
     td{
        padding: 8px 8px;
        display: table-cell;
        text-align: left;
        vertical-align: top;
        font-family:'Trebuchet MS';
        color:white;
        border-radius: 24px ;
        font-weight:bolder;
     }
    tr{
        font-family:'Trebuchet MS';
        color:white;
        font-weight:bolder;
    }


    body{
    
    background-image: url("20210221_190017_0000.png") ;
    background-attachment: fixed;  
    background-size:cover;
    background-position: center;
    }

    /*img{
        width: 125px;
        height: 125px;
        ;
    }*/
    h2{
        font-family:'Trebuchet MS';
        font-size: 40px;
        color:white;
        
    }
    h3{
        font-family:'Trebuchet MS';
        color:white;
        font-size: 30px;
    }

    h4{
        font-family:'Trebuchet MS';
        color:white;
        font-size: 20px;
    }
    .email{
position: relative;
left: 200px;
top: -37px;
line-height: 40px;
width: 480px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
}
    /*.divClass {
    border: 10px solid #fff8ff;/
    /background-color:rgb(236, 219, 188);
    }
    .data{
    /border: 10px solid rgb(236, 219, 188);/
    /background-color: #fff8ff;/
    }*/

    .line{
   height: 4px;
   width: 510px;
   border-radius: 6px;
   position: absolute;
   left: 30%;
   top: 19%;
   background: linear-gradient(to left,rgb(43, 190, 183),rgb(3, 44, 42));
}
.regform h1 span{
 color: #319c8e;
 font-weight: bolder;

}
.regform1 h2 span{
 color:#319c8e ;
 border-radius: 0px;
 font-weight: bolder;

}
.name{
 padding: 4px 20px;
 border-radius: 6px;
}
.date{
    padding: 4px 20px;
    border-radius: 6px;
   }
.number{
    padding: 4px 20px;
    border-radius: 6px;
   }
   .number2{
    padding: 4px;
    border-radius: 6px;
   }
#email{
    padding: 4px;
    border-radius: 6px;
}
.address{
    
    font-family:'Trebuchet MS';
        width: 1000px;
        margin: auto;
        color: #FFFFFF;
        text-align: center;
        border-radius:0px 0px 0px 0px;
        font-size:20px;
}
 .name2{
     padding: 4px;
     border-radius: 6px;
 }  
    .buttonCls{
       border-radius: 10px;
       width: 250px;
       height: 25px;
       background-color:black;
       color:white;
       opacity: 0.7;
       font-size:18px;
    }
    .button{
        font-family:'Trebuchet MS';
       border-radius: 10px;
       width: 150px;
       height: 25px;
       background-color:#319c8e;
       color:white;
       opacity: 0.7;
       text-align:center;
       font-size:18px;
    }
    .b{
        border-radius: 10px;
       width: 400px;
       height: 25px;
       background-color:black;
       color:white;
       opacity: 0.6;
       font-size:18px;
    }
    .buttonCls{
       border-radius: 10px;
       width:200px;
       height: 25px;
       background-color:#003366;
       color:white;
       opacity: 0.5;
       font-size:18px;
    }
</style>
 <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
 
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 <title>EnrollmentForm</title>
 <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
</head>

<body>
<div>
<?php
if(array_key_exists('submit', $_POST)) { 
 organisationDetails();
  
}
function  organisationDetails()
{

$conn=mysqli_connect('localhost','root','','orphanage_');
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
 }
 ?>
    <div class="regform"><h1>Thank you<br><br></h1>
	<h2>PLEASE ENTER YOUR BASIC NEEDS TO DISPLAY YOUR DETAILS <br></h2></div>
	<p><center>click on next button</center></p><br>
	<div align="center">
	<br>
	<a href="orphanage_requirements.php"><div class="buttoncls">NEXT</div></a>
	</div>

   <?php


IF($_POST['name']!=''and $_POST['fname']!=''and $_POST['d_no']!='')
{
    $name=$_POST['name'];
    $DOE=$_POST['DOE'];
    $capacity=$_POST['Capacity'];
    $boys=$_POST['Boys'];
    $girls=$_POST['Girls'];
    $staff=$_POST['Staff'];
    $Contact_Number=$_POST['Contact_Number'];
    $Contact_Number2=$_POST['Contact_Number2'];
    $landline=$_POST['landline'];
    $email=$_POST['E-mail'];
    mysqli_query($conn ,"INSERT INTO organisation(`orphanage_name`, `date_of_establishment`, `capacity`,`boys`, `girls`, `staff`,`phn_no1`,`phn_no2`,`landline`, `email_address`)
      values ('$name','$DOE','$capacity','$boys','$girls','$staff','$Contact_Number','$Contact_Number2','$landline','$email')");

	
	
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $gender=$_POST['gender'];
    $DOB=$_POST['DOB'];
    $email=$_POST['email'];
    $phn_no=$_POST['phn_no'];
    $phn_no2=$_POST['phn_no2'];
    $gender = $_POST["gender"];
    }
    mysqli_query($conn ,"INSERT INTO manager_details(`firstname`, `lastname`, `gender`, `DOB`,`phn_no`,`phn_no2`, `email_id`)
      values ('$fname','$lname','$gender','$DOB','$phn_no','$phn_no2','$email')");

    $d_no=$_POST['d_no'];
    $street=$_POST['street'];
    $colony=$_POST['colony'];
    $area=$_POST['area'];
    $city=$_POST['city'];
    $state=$_POST['state'];
    $pin=$_POST['pin'];
    mysqli_query($conn ,"INSERT INTO contact_details(`d_no`, `street`, `colony`, `area`, `city`, `state`, `pincode`)
      values ('$d_no','$street','$colony','$area','$city','$state','$pin')");
  
  if($_FILES['orphanage_photo']['name']!='' and  $_FILES['loc']['name']!='' and $_FILES['manager']['name']!='' and $_FILES['id_proof']['name']!='' and $_FILES['id_proof']['name']!='' 
  and $_FILES['govt_certificate']['name']!='' and $_POST['bill']!='' )
 {
    $errors = []; // Store errors here

    $fileExtensionsAllowed = ['jpeg','jpg','png'];
$filename = $_FILES['orphanage_photo']['name'];
$filetmpname = $_FILES['orphanage_photo']['tmp_name'];
$fileSize = $_FILES['orphanage_photo']['size'];
$tmp= explode('.', $filename);
$fileExtension = end($tmp);
$folder = 'orphanage_photo/';

$errors1 = [];
$filename1 = $_FILES['loc']['name'];
$filetmpname1 = $_FILES['loc']['tmp_name'];
$fileSize1 = $_FILES['loc']['size'];
$folder1= 'loc_proof/';
$tmp1= explode('.', $filename1);
$fileExtension1 = end($tmp1);
$bill=$_POST['bill'];

$errors2 = [];
$filename2 = $_FILES['manager']['name'];
$filetmpname2 = $_FILES['manager']['tmp_name'];
$fileSize2 = $_FILES['manager']['size'];
$folder2= 'manager_photo/';
$tmp2= explode('.', $filename2);
$fileExtension2 = end($tmp2);

$errors3 = [];
$filename3 = $_FILES['id_proof']['name'];
$filetmpname3 = $_FILES['id_proof']['tmp_name'];
$fileSize3 = $_FILES['id_proof']['size'];
$folder3= 'ID_proof/';
$tmp3= explode('.', $filename3);
$fileExtension3 = end($tmp3);
$adhar_no=$_POST['adhar_no'];

$errors4 = [];
$filename4 = $_FILES['govt_certificate']['name'];
$filetmpname4 = $_FILES['govt_certificate']['tmp_name'];
$fileSize4 = $_FILES['govt_certificate']['size'];
$folder4= 'govt_certificate/';
$tmp4= explode('.', $filename4);
$fileExtension4 = end($tmp4);



if (! in_array($fileExtension,$fileExtensionsAllowed)) {
    $errors[] = "<br>The file extension of " . basename($filename) . "  is not allowed for ORPHANAGE PHOTO.Please upload a JPEG or PNG file";
  }
  if (! in_array($fileExtension1,$fileExtensionsAllowed)) {
    $errors1[] = "<br>This file extension of " . basename($filename1) . "  is not allowed for LOCATION PROOF.Please upload a JPEG or PNG file";
  }
  if (! in_array($fileExtension2,$fileExtensionsAllowed)) {
    $errors2[] = "<br>This file extension of " . basename($filename2) . "  is not allowed for MANAGER PHOTO.Please upload a JPEG or PNG file";
  }
  if (! in_array($fileExtension3,$fileExtensionsAllowed)) {
    $errors3[] = "<br>This file extension of " . basename($filename3) . "  is not allowed for ID PROOF.Please upload a JPEG or PNG file";
  }
  if (! in_array($fileExtension4,$fileExtensionsAllowed)) {
    $errors4[] = "<br>This file extension of " . basename($filename4) . "  is not allowed for ID PROOF.Please upload a JPEG or PNG file";
  }

  if ($fileSize > 4000000) {
    $errors[] = "<br>". basename($filename) . " exceeds maximum size (4MB) for ORPHANAGE PHOTO";
  }
  if ($fileSize1 > 4000000) {
    $errors1[] = "<br>". basename($filename1) . " exceeds maximum size (4MB) for LOCATION PROOF";
  }

  if ($fileSize2 > 4000000) {
    $errors2[] = "<br>". basename($filename2) . " exceeds maximum size (4MB) for MANAGER PHOTO";
  }
  if ($fileSize3 > 4000000) {
    $errors3[] = "<br>". basename($filename3) . " exceeds maximum size (4MB) for ID PROOF";
  }
  if ($fileSize4 > 4000000) {
    $errors4[] = "<br>". basename($filename4) . " exceeds maximum size (4MB) for GOVT CERTIFICATE";
  }

  if (empty($errors)) {
    $didUpload = move_uploaded_file($filetmpname, $folder.$filename);
    $didUpload1 = move_uploaded_file($filetmpname1, $folder1.$filename1);
    $didUpload2 = move_uploaded_file($filetmpname2, $folder2.$filename2);
    $didUpload3 = move_uploaded_file($filetmpname3, $folder3.$filename3);
    $didUpload4 = move_uploaded_file($filetmpname4, $folder4.$filename4);
    
    
    
    mysqli_query($conn ,"INSERT INTO verification_details(`orphanage_photo`,`loc_proof`,`manager_image`,`bill`,`adhar_no`,`id_proof`,`govt_certificate`)
    values ('$filename','$filename1','$filename2','$bill','$adhar_no','$filename3','$filename4')");

    if ($didUpload) {
      /*echo "<br>The file " . basename($filename) . " has been uploaded";*/
    } 
    if ($didUpload1) {
      /* echo "<br>The file " . basename($filename1) . " has been uploaded";*/
    } 
    if ($didUpload2) {
      /* echo "<br>The file " . basename($filename2) . " has been uploaded";*/
    } 
    if ($didUpload3) {
      /* echo "<br>The file " . basename($filename3) . " has been uploaded";*/
    }
    if ($didUpload4) {
     /*  echo "<br>The file " . basename($filename4) . " has been uploaded";*/
    } 

 }  else {
    foreach ($errors as $error) {
      echo "<br>" . $error  ;
    }
    foreach ($errors1 as $error1) {
      echo "<br>" . $error1 ;
    }
    foreach ($errors2 as $error2) {
      echo "<br>" . $error2 ;
    }
    foreach ($errors3 as $error3) {
      echo "<br>" . $error3 ;
    }
    foreach ($errors4 as $error4) {
      echo "<br>" . $error4 ;
    }
  }
 

$data = $_POST;

if ($data['acc'] !== $data['re_acc'] or $data['IFSC'] !== $data['re_IFSC'] or $data['UPI'] !== $data['re_UPI'] ) {
echo '<script>alert("Account details are not matched")</script>'; 
 
}
else if($_POST['bank_name']!=''){
$bank_name=$_POST['bank_name'];
$branch=$_POST['branch'];
$branch_code=$_POST['branch_code'];
$acc=$_POST['acc'];
$re_acc=$_POST['re_acc'];
$IFSC=$_POST['IFSC'];
$re_IFSC=$_POST['re_IFSC'];
$UPI=$_POST['UPI'];
$re_UPI=$_POST['re_UPI'];
if ($data['acc'] == $data['re_acc']) {
    mysqli_query($conn ,"INSERT INTO bank_details(`bank_name`,`branch`,`branch_pincode`,`acc_no`,`re_acc`,`IFSC_code`,`re_IFSC`,`UPI_id`,`re_UPI`) 
VALUES ('$bank_name', '$branch', '$branch_code', '$acc', '$re_acc','$IFSC','$re_IFSC','$UPI','$re_UPI')");

 }}

 $avg=$_POST['avg'];
        $Sponsers=$_POST['Sponsers'];
        $branch1=$_POST['branch1'];
        $branch2=$_POST['branch2'];
        $branch3=$_POST['branch3'];
        $Instagram_UserID=$_POST['Instagram_UserID'];
        $Instagram_URL = $_POST["Instagram_URL"];
        $Facebook_UserID=$_POST['Facebook_UserID'];
        $Facebook_URL=$_POST['Facebook_URL'];
        $Twitter_UserID=$_POST['Twitter_UserID'];
        $Twitter_URL=$_POST['Twitter_URL'];
IF($avg!='' or $Sponsers !='' or $Instagram_UserID !='' or $Instagram_URL !='' or $Facebook_UserID !='' 
            or $Facebook_URL !='' or $Twitter_UserID !='' or $Twitter_URL !='' or $branch1 !='' or $branch2 !='' or $branch3 !='' )
{
        mysqli_query($conn ,"INSERT INTO other_info(`avg_turn_over`,`sponsers`,`instagram_id`,`instagram_url`,`facebook_id`,`fb_url`,`twitter_id`,`twitter_url`)
          values ('$avg','$Sponsers','$Instagram_UserID','$Instagram_URL','$Facebook_UserID','$Facebook_URL','$Twitter_UserID','$Twitter_URL')");
        mysqli_query($conn ,"INSERT INTO other_info_3(`branch1`,`branch2`,`branch3`)
        values ('$branch1','$branch2','$branch3')");
}
$last_id = mysqli_insert_id($conn);
//echo "<br>ID for your orphanage is:" . $last_id;
$message = "ID for your orphanage is ";
//echo "<script>alert('Form Submitted Successfully..!!');</script>";
echo "<script>alert('$message'+'$last_id');</script>";

//$message = "ID for your orpahage is:";
//echo "<script type='text/javascript'>alert('$message'+'$last_id');</script>";
exit;

}
else
  {
    echo '<script>alert("Please Fill All Your Details")</script>';
  }
}   


?>

</div>
 
 
 <section >
    <div class="regform"><h1><span>O</span>RPHANAGE <span>ENROLL</span>MENT</h1></div>

    <div class="main">
    <form action="##" method="post" enctype="multipart/form-data" >
    <div class="regform1"><h2><span>Ab</span>out <span>Org</span>anisation</h2></div>
            <div class="divClass">
            <table>
            
                <tr>
                   <td> Name of the Orphanage </td>
                   <td><input type="text"  name="name" pattern="[a-zA-Z-' ]{1,}" required></td>
                </tr>
                <tr>
                    <td>Date of Establishment</td>
                    <td><input type="date" name="DOE" required></td>
                </tr>
                <tr>
                    <td>Capacity of the Orphanage</td>
                    <td><input type="number" name="Capacity" required></td>
                </tr>
                <tr>
                    <td>Number of Boys</td>
                    <td><input type="number" name="Boys" required></td>
                </tr>
                <tr>
                    <td>Number of Girls</td>
                    <td><input type="number" name="Girls" required></td>
                </tr>
                <tr>
                    <td>Number of Staff</td>
                    <td><input type="number" name="Staff" required></td>
                </tr>
                <tr>
                    <td>Contact Number</td>
                    <td><input type="tel" name="Contact_Number" pattern="[6-9]{1}[0-9]{9}" required></td>
                    <td><input type="tel" name="Contact_Number2" pattern="[6-9]{1}[0-9]{9}"></td> 
                </tr>
                <tr>
                    <td>Landline Number</td>
                    <td><input type="tel" name="landline" placeholder="AAA-BBBBBBB" pattern="[0]{1}[0-9]{9}"></td> 
                </tr>
                <tr>
                    <td>E-mail ID</td>
                    <td><input type="email" id="email" name="E-mail" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}" required></td>
                </tr>
                
            </table>
            </div>
            
            <div class="data">
                <table>
                
                <div class="regform1"><h2><span>Man</span>ager <span>D</span>etails</h2></div>
                <tr>
                    <td>First Name</td>
                    <td><input type ="text"  name="fname" pattern="[a-zA-Z-' ]{1,}" required></td>
                    <td>Last Name</td>
                    <td><input type ="text"  name="lname" pattern="[a-zA-Z-' ]{1,}" ></td>
                </tr>
                <tr>
                <td>Gender</td>
                <td> <select required name="gender">
        <option value="" disabled selected hidden>--choose Gender--</option>
        <option>Male</option>
        <option>Female</option>
        <option>other</option>
    </select></td></tr>
                <tr>
                    <td>Date of Birth</td>
                    <td><input type="date" name="DOB" required></td>
                </tr>
                <tr>
                    <td>Phone Number</td>
                    <td><input type="text"  name="phn_no" pattern="[6-9]{1}[0-9]{9}" required></td>
                    <td><input type="text"  name="phn_no2" pattern="[6-9]{1}[0-9]{9}"></td>
                </tr>
                
                <tr>
                    <td>Email</td>
                    <td><input type="email" id="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}" required></td>
                </tr>
            </table>

            </div>
            
            
           <div class="divClass">
                <table>
                <div class="regform1"><h2><span>Cont</span>act <span>D</span>etails</h2></div>
                <div class="address"><h4>ADDRESS</h4></div>
                    <tr>
                        <td >Door number</td>
                        <td><input type="text" name="d_no" required></td>
                        <td >Street Name</td>
                        <td><input type="text" name="street"></td>
                        <td >Colony</td>
                        <td><input type="text" name="colony"></td>
                    </tr>
                    <tr>
                        <td >Area</td>
                        <td><input type="text" name="area" pattern="[a-zA-Z-' ]{1,}" required></td>
                        <td >City</td>
                        <td><input type="text" name="city" pattern="[a-zA-Z-' ]{1,}" required></td>
                    </tr>
                    <tr></tr>
                        <td >State</td>
                        <td><input type="text" name="state" pattern="[a-zA-Z-' ]{1,}" required></td>

                        <td >Pin Code</td>
                        <td><input type="int" name="pin" pattern="\d{4}|\d{6}" required></td>
                    </tr>
                    
                </table>

            </div>
            <div class="data">
                <table>
                <div class="regform1"><h2><span>Verif</span>ication <span>D</span>etails</h2></div>
                    <tr>
                        <td>Orphanage Photo</td>
                        <td colspan="2"><input type ="file" value="upload" name="orphanage_photo" class="buttonCls"  required></td>
                    </tr>
                    <tr>
                        <td>Location Proof (Last Paid Current Bill )</td>
                        <td><input type="text" name="bill" pattern="[0-9]{1,7}" required></td>
                        <td colspan="2"><input type ="file" value="upload" name="loc" class="buttonCls"  required></td>
                    </tr>
                    <tr>
                    <td>Manager Photo</td>
                    <td colspan="2"><input type="file"  value="upload" name="manager" class="buttonCls" required></td>
                    </tr>
                    <tr>
                    <td>ID Proof (Aadhar Number)</td>
                    <td><input type="text" maxlength="12" name="adhar_no" pattern="[0-9]{12}" required></td>
                    <td colspan="2"><input type ="file" value="upload" name="id_proof" class="buttonCls" required></td>
                    </tr>
                    <tr>
                    <td>Government certificate(PROOF)</td>
                    <td colspan="2"><input type ="file" value="upload" name="govt_certificate" class="buttonCls"  required></td>
                    </tr>
                    
        
            <div class="divClass">
                <table>
                <div class="regform1"><h2><span>B</span>ank <span>D</span>etails</h2></div>
                    <tr>
                        <td>Bank Name</td>
                        <td><input type="text" name="bank_name" pattern="[a-zA-Z-' ]{1,}" required></td>
                    </tr>
                    <tr>
                        <td>Branch</td>
                        <td><input type="text" name="branch" pattern="[a-zA-Z-' ]{1,}" required></td>
                    </tr>
                    <tr>
                        <td>Branch PINCODE</td>
                        <td><input type="int" name="branch_code" pattern="\d{4}|\d{6}" required></td>
                    </tr>
                    <tr>
                        <td>Account Number</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" name="acc" pattern="\d{1,16}" required></td>
                    </tr>
                    <tr>
                        <td>Reenter Account Number</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" pattern="\d{1,16}" name="re_acc" required></td>
                    </tr>
                    <tr>
                        <td>IFSC Code</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" name="IFSC" pattern="[A-Z]{4}0[A-Z0-9]{6}" required></td>
                    </tr>
                    <tr>
                        <td>Reenter IFSC Code</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" name="re_IFSC" pattern="[A-Z]{4}0[A-Z0-9]{6}" required></td>
                    </tr>
                    <tr>
                        <td>Phone Number</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" name="UPI" pattern="[6-9]{1}[0-9]{9}" required></td>
                    </tr>
                    <tr>
                        <td>Reenter Phone Number</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" name="re_UPI" pattern="[6-9]{1}[0-9]{9}" required></td>
                    </tr>
                    
                    
                </table>
            </div>

           <div class="divClass">
                <table>
                <div class="regform1"><h2><span>Othe</span>r <span>Info</span>rmation</h2></div>
                    <tr>
                        <td>Average Turn Over of the Orphanage</td>
                        <td><input type="text" name="avg" pattern="[0-9]{1,7}" required></td>
                    </tr>
                    <tr>
                        <td>Key Sponsers</td>
                        <td><input type="text" name="Sponsers" pattern="[a-zA-Z-' ]{1,}"></td>
                    </tr>
                    <tr>
                        <td>Any other Branches</td>
                        <td><input type="text" name="branch1" pattern="[a-zA-Z-' ]{1,}" ></td>
                        <td><input type="text" name="branch2" pattern="[a-zA-Z-' ]{1,}"></td>
                        <td><input type="text" name="branch3" pattern="[a-zA-Z-' ]{1,}"></td>
                    </tr>
                    <tr>
                        <td>Instagram UserID</td>
                        <td><input type="text" name="Instagram_UserID" ></td>
                        <td colspan="2"><input type="url" name="Instagram_URL" placeholder="Enter Instagram ID URL " pattern="https://.*" class="b"></td>
                    </tr>
                    <tr>
                        <td>Facebook UserID</td>
                        <td><input type="text" name="Facebook_UserID"></td>
                        <td colspan="2"><input type="url" name="Facebook_URL" placeholder="Enter Facebook ID URL" pattern="https://.*" class="b"></td>
                    </tr>
                    <tr>
                        <td>Twitter UserID</td>
                        <td><input type="text" name="Twitter_UserID"></td>
                        <td colspan="2"><input type="url" name="Twitter_URL" placeholder="Enter Twitter ID URL" pattern="https://.*" class="b"></td>
                    </tr>
                </table>
            </div>
            <div class="data">
                    <table align="center">
                     <tr>
                        <td colspan="2" >
                        <input type="submit"  value="SAVE & SUBMIT" name="submit" class="button" ></td>
                            
                     </tr>
                </table>
            </div>
        </form>
</div>
</section>
</body>
</html>
