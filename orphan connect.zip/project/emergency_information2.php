<!DOCTYPE html>
<html>
<style>
* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    overflow-x: hidden;
    font-family:'Trebuchet MS';
    
}
html {
    font-size: 10px;
    font-family: 'Montserrat', sans-serif;
    scroll-behavior: smooth;
    background-color:#319c8e;
}
a {
    text-decoration: none;
}
.container {
    min-height: 100vh;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
}
img {
    height: 100%;
    width: 100%;
    object-fit: cover;
}
p {
    color: black;
    font-size: 1.4rem;
    margin-top: 5px;
    line-height: 2.5rem;
    font-weight: 300;
    letter-spacing: .05rem;
}
.section-title {
    font-size: 4rem;
    font-weight: 300;
    color: black;
    margin-bottom: 10px;
    text-transform: uppercase;
    letter-spacing: .2rem;
    text-align: center;
}
.section-title span {
    color: rgb(54, 170, 179);
}

.cta {
    display: inline-block;
    padding: 10px 30px;
    color: white;
    background-color: transparent;
    border: 2px solid rgb(53, 158, 161);
    font-size: 2rem;
    text-transform: uppercase;
    letter-spacing: .1rem;
    margin-top: 30px;
    transition: .3s ease;
    transition-property: background-color, color;
}
.cta:hover {
    color: white;
    background-color:  rgb(107, 109, 109);
}
.cta2{
    display: inline-block;
    padding: 20px 40px;
    color: white;
    background-color: rgb(145, 146, 146);
    border: 2px solid rgb(53, 158, 161);
    font-size: 2rem;
    text-transform: uppercase;
    letter-spacing: .1rem;
    margin-top: 30px;
    transition: .3s ease;
    transition-property: background-color, color;
}
.cta2:hover {
    color: white;
    background-color:  rgb(107, 109, 109);
}
.brand h1 {
    font-size: 3rem;
    text-transform: uppercase;
    color: white;
   
    
}
.brand h1 span {
    color:  rgb(53, 158, 161);
    
}

.img2{
    width: 170px;
    height: 180px;
    background: transparent;
    transform: translate(-20%, -20%);
    position: absolute;
    top: 15px;
    left: 30px;
    overflow-y: hidden;
}

#header {
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 105vw;
    height: auto;
}
#header .header 
{ opacity:0.6;
    min-height: 8vh;
    background-color: #29323c;
    transition: .3s ease background-color;
}
#header .nav-bar {
    
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    height: 100%;
    max-width: 1300px;
    padding: 0 10px;
}
#header .nav-list ul {
    list-style: none;
    position: absolute;
    background-color: rgb(31, 30, 30);
    width: 100vw;
    height: 100vh;
    left: 100%;
    top: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    z-index: 1;
    overflow-x: hidden;
    transition: .5s ease left;
}
#header .nav-list ul.active {
    left: 0%;
}
#header .nav-list ul a {
    font-size: 2.5rem;
    font-weight: 500;
    letter-spacing: .2rem;
    text-decoration: none;
    color: white;
    text-transform: uppercase;
    padding: 20px;
    display: block;
}
#header .nav-list ul a::after {
    content: attr(data-after);
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) scale(0);
    color: rgba(240, 248, 255, 0.021);
    font-size: 13rem;
    letter-spacing: 50px;
    z-index: -1;
    transition: .3s ease letter-spacing;
}
#header .nav-list ul li:hover a::after {
    transform: translate(-50%, -50%) scale(1);
    letter-spacing: initial;
}
#header .nav-list ul li:hover a {
    color:  rgb(53, 158, 161);
}
#header .hamburger {
    height: 60px;
    width: 60px;
    display: inline-block;
    border: 3px solid white;
    border-radius: 50%;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 100;
    cursor: pointer;
    transform: scale(.8);
    margin-right: 20px;
}
#header .hamburger:after {
    position: absolute;
    content: '';
    height: 100%;
    width: 100%;
    border-radius: 50%;
    border: 3px solid white;
    animation: hamburger_puls 1s ease infinite;
}
#header .hamburger .bar {
    height: 2px;
    width: 30px;
    position: relative;
    background-color: white;
    z-index: -1;
}
#header .hamburger .bar::after,
#header .hamburger .bar::before {
    content: '';
    position: absolute;
    height: 100%;
    width: 100%;
    left: 0;
    background-color: white;
    transition: .3s ease;
    transition-property: top, bottom;
}
#header .hamburger .bar::after {
    top: 8px;
}
#header .hamburger .bar::before {
    bottom: 8px;
}
#header .hamburger.active .bar::before {
    bottom: 0;
}
#header .hamburger.active .bar::after {
    top: 0;
}
#header img{
    width: 45px;
    height: 45px;
    position: absolute;
    top: 10px;
    left: 50%;
    
    transform: translate(50px);
}
.brand img{
    width: 50px;
    height: 50px;
    color: white;
}
.opt {
    cursor: pointer;
    padding: 10px 30px;
    color: rgb(68, 66, 66);
    background-color: transparent;
    border: 2px solid rgb(27, 131, 145);
    font-size: 2rem;
    text-transform: uppercase;
    letter-spacing: .1rem;
    margin-top: 30px;
    transition: .3s ease;
    transition-property: background-color, color;
}
.opt:hover {
    color: rgb(34, 33, 33);
    background-color: rgb(135, 136, 136);
}
#hero {
    background-image: url(./C:\Users\veerendra\Desktop\v.png);
    background-size: cover;
    background-position: top center;
    position: relative;
    z-index: 1;
}
#mySidenav a {
    position: absolute;
    right: -182px;
   
    transition: 0.3s;
    padding: 15px;
    width: 220px;
    height: 50px;
    text-decoration: none;
    font-size: 20px;
    overflow-y: hidden;
    color: white;
    border-radius: 5px 0 0 5px;
  }
  
  #mySidenav a:hover {
    right: 0;
  }
  
  
  #a {
    top: 160px;
    background-color: #319c8e;
  }
  
  #b {
    top: 230px;
    background-color: #f3214f;
  }
  
  #c {
    top: 300px;
    background-color: #1deee3;
  }
  
  #d {
    top: 370px;
    background-color: rgb(55, 219, 170)
  }
  #e {
    top: 440px;
    background-color: rgb(189, 39, 109)
  }

#hero::after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 100%;
    background-color: black;
    opacity: .7;
    z-index: -1;
}
#hero .hero {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 50px;
    justify-content: flex-start;
}
#hero h1 {
    display: block;
    width: fit-content;
    font-size: 4rem;
    position: relative;
    color: transparent;
    animation: text_reveal .5s ease forwards;
    animation-delay: 1s;
}
#hero h1:nth-child(1) {
    animation-delay: 1s;
}
#hero h1:nth-child(2) {
    animation-delay: 2s;
}
#hero h1:nth-child(3) {
    animation: text_reveal_name .5s ease forwards;
    animation-delay: 3s;
}
#hero h1 span {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 0;
    background-color: rgba(27, 131, 145);
    animation: text_reveal_box 1s ease;
    animation-delay: .5s;
}
#hero h1:nth-child(1) span {
    animation-delay: .5s;
}
#hero h1:nth-child(2) span {
    animation-delay: 1.5s;
}
#hero h1:nth-child(3) span {
    animation-delay: 2.5s;
}


#services .services {
    flex-direction: column;
    text-align: center;
    max-width: 1500px;
    margin: 0 auto;
    padding: 100px 0;
}
#services .service-top {
    max-width: 500px;
    margin: 0 auto;
}
#services .service-bottom {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-wrap: wrap;
    margin-top: 50px;
}
#services .service-item {
    flex-basis: 80%;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    flex-direction: column;
    padding: 30px;
    border-radius: 10px;
    background-image: url("https://thumbs.gfycat.com/DevotedCarelessJackal-size_restricted.gif");
    background-size: cover;
    margin: 10px 5%;
    position: relative;
    z-index: 1;
    overflow: hidden;
}
#services .service-item::after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 100%;
    background-image: linear-gradient(60deg, #29323c 0%, #485563 100%);
    opacity: .9;
    z-index: -1;
}
#services .service-bottom .icon {
    height: 80px;
    width: 80px;
    overflow-y: hidden;
    margin-bottom: 20px;
}
#services .service-item h2 {
    font-size: 2rem;
    color: white;
    margin-bottom: 10px;
    text-transform: uppercase;
}
#services .service-item p {
    color: white;
    text-align: left;
}

#projects .projects {
    flex-direction: column;
    max-width: 1200px;
    margin: 0 auto;
    padding: 100px 0;
}
#projects .projects-header h1 {
    margin-bottom: 50px;
}
#projects .all-projects {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
}
#projects .project-item {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    width: 80%;
    margin: 20px auto;
    overflow: hidden;
    border-radius: 10px;
}
#projects .project-info {
    padding: 30px;
    flex-basis: 50%;
    height: 100%;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    flex-direction: column;
    background-image: linear-gradient(60deg, #29323c 0%, #485563 100%);
    color: white;
}
#projects .project-info h1 {
    font-size: 4rem;
    font-weight: 500;
}
#projects .project-info h2 {
    font-size: 1.8rem;
    font-weight: 500;
    margin-top: 10px;
}
#projects .project-info p {
    color: white;
}
#projects .project-img {
    flex-basis: 50%;
    height: 300px;
    overflow: hidden;
    position: relative;
}
#projects .project-img:after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 100%;
    background-image: linear-gradient(60deg, #70b8bb 0%, #a3d8db 100%);
    opacity: .7;
}
#projects .project-img img {
    transition: .3s ease transform;
}
#projects .project-item:hover .project-img img {
    transform: scale(1.1);
}
#about .about {
    flex-direction: column-reverse;
    text-align: center;
    max-width: 1200px;
    margin: 0 auto;
    padding: 100px 20px;
}
#about .col-left {
    width: 250px;
    height: 360px;
}
#about .col-right {
    width: 100%;
}
#about .col-right h2 {
    font-size: 1.8rem;
    font-weight: 500;
    letter-spacing: .2rem;
    margin-bottom: 10px;
}
#about .col-right p {
    margin-bottom: 20px;
}
#about .col-right .cta {
    color: black;
    margin-bottom: 50px;
    padding: 10px 20px;
    font-size: 2rem;
}
#about .col-left .about-img {
    height: 100%;
    width: 100%;
    position: relative;
    border: 10px solid white;
}
#about .col-left .about-img::after {
    content: '';
    position: absolute;
    left: -33px;
    top: 19px;
    height: 98%;
    width: 98%;
    border: 7px solid rgb(55, 135, 141);
    z-index: -1;
}

#contact .contact {
    
    max-width: 1200px;
    margin: 0 auto;
}
#contact .contact-items {
    width: 400px;
}
#contact .contact-item {
    width: 80%;
    padding: 20px;
    text-align: center;
    border-radius: 10px;
    padding: 30px;
    margin: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    box-shadow: 0px 0px 18px 0 #0000002c;
    transition: .3s ease box-shadow;
}
#contact .contact-item:hover {
    box-shadow: 0px 0px 5px 0 #0000002c;
}
#contact .icon {
    width: 70px;
    overflow-y: hidden;
    margin: 0 auto;
    margin-bottom: 10px;
}
#contact .contact-info h1 {
    font-size: 2.5rem;
    font-weight: 500;
    margin-bottom: 5px;
}
#contact .contact-info h2 {
    font-size: 1.3rem;
    line-height: 2rem;
    font-weight: 500;
}

#footer {
    background-image: linear-gradient(60deg, #29323c 0%, #485563 100%);
}
#footer .footer {
    min-height: 200px;
    flex-direction: column;
    padding-top: 50px;
    padding-bottom: 10px;
}
#footer h2 {
    color: white;
    font-weight: 500;
    font-size: 1.8rem;
    letter-spacing: .1rem;
    margin-top: 10px;
    margin-bottom: 10px;
}
#footer .social-icon {
    display: flex;
    
    margin-bottom: 30px;
}
#footer .social-item {
    height: 50px;
    width: 50px;
    overflow-y: hidden;
    margin: 0 5px;
}
#footer .social-item img {
    filter: grayscale(1);
    overflow-y: hidden;
    transition: .3s ease filter;
}
#footer .social-item:hover img {
    filter: grayscale(0);
}
#footer p {
    color: white;
    font-size: 1.3rem;
}
@keyframes hamburger_puls {
    0% {
        opacity: 1;
        transform: scale(1);
    }
    100% {
        opacity: 0;
        transform: scale(1.4);
    }
}
@keyframes text_reveal_box {
    50% {
        width: 100%;
        left: 0;
    }
    100% {
        width: 0;
        left: 100%;
    }
}
@keyframes text_reveal {
    100% {
        color: white;
    }
}
@keyframes text_reveal_name {
    100% {
        color: rgb(31, 133, 128);
        font-weight: 500;
    }
}

@media only screen and (min-width: 768px) {
    .cta {
        font-size: 2.5rem;
        padding: 20px 60px;
    }
    h1.section-title {
        font-size: 6rem;
    }

    
    #hero h1 {
        font-size: 7rem;
    }
    
    #services .service-bottom .service-item {
        flex-basis: 45%;
        margin: 2.5%;
    }
    
    #projects .project-item {
        flex-direction: row;
    }
    #projects .project-item:nth-child(even) {
        flex-direction: row-reverse;
    }
    #projects .project-item {
        height: 400px;
        margin: 0;
        width: 100%;
        border-radius: 0;
    }
    #projects .all-projects .project-info {
        height: 100%;
    }
    #projects .all-projects .project-img {
        height: 100%;
    }
    
    #about .about {
        flex-direction: row;
    }
    #about .col-left {
        width: 600px;
        height: 400px;
        padding-left: 60px;
    }
    #about .about .col-left .about-img::after {
        left: -45px;
        top: 34px;
        height: 98%;
        width: 98%;
        border: 10px solid rgb(43, 152, 160);
    }
    #about .col-right {
        text-align: left;
        padding: 30px;
    }
    #about .col-right h1 {
        text-align: left;
    }
    
    #contact .contact {
        flex-direction: column;
        padding: 100px 0;
        align-items: center;
        justify-content: center;
        min-width: 20vh;
    }
    #contact .contact-items {
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: space-evenly;
        margin: 0;
    }
    #contact .contact-item {
        width: 30%;
        margin: 0;
        flex-direction: row;
    }
    #contact .contact-item .icon {
        height: 100px;
        width: 100px;
    }
    #contact .contact-item .icon img {
        object-fit: contain;
    }
    #contact .contact-item .contact-info {
        width: 100%;
        text-align: left;
        padding-left: 20px;
    }
    
@media only screen and (min-width: 1200px) {
    
    #header .hamburger {
        display: none;
    }
    #header .nav-list ul {
        position: initial;
        display: block;
        height: auto;
        width: fit-content;
        background-color: transparent;
    }
    #header .nav-list ul li {
        display: inline-block;
    }
    #header .nav-list ul li a {
        font-size: 1.8rem;
    }
    #header .nav-list ul a:after {
        display: none;
    }
    

    #services .service-bottom .service-item {
        flex-basis: 22%;
        margin: 1.5%;
    }
}
.like-content {
    display: inline-block;
    width: 100%;
    margin: 40px 0 0;
    padding: 40px 0 0;
    font-size: 18px;
    border-top: 10px dashed #eee;
    text-align: center;
}
.like-content span {
    color: #9d9da4;
    font-family: monospace;
}
.like-content .btn-secondary {
      display: block;
      margin: 40px auto 0px;
    text-align: center;
    background: #ed2553;
    border-radius: 3px;
    box-shadow: 0 10px 20px -8px rgb(240, 75, 113);
    padding: 10px 17px;
    font-size: 18px;
    cursor: pointer;
    border: none;
    outline: none;
    color: #ffffff;
    text-decoration: none;
    -webkit-transition: 0.3s ease;
    transition: 0.3s ease;
}
.like-content .btn-secondary:hover {
      transform: translateY(-3px);
}
.like-content .btn-secondary .fa {
      margin-right: 5px;
}
.animate-like {
    animation-name: likeAnimation;
    animation-iteration-count: 1;
    animation-fill-mode: forwards;
    animation-duration: 0.65s;
}
@keyframes likeAnimation {
  0%   { transform: scale(30); }
  100% { transform: scale(1); }
}
@import url(https://fonts.googleapis.com/css?family=Open+Sans);
.search {
    width: 100%;
    position: relative;
    display: flex;
  }
  
  .searchTerm {
    width: 5000px;
    border: 2px solid black;
    border-right: none;
    padding: 5px;
    height: 40px;
    border-radius: 5px 0 0 5px;
    outline: none;
    color: #9DBFAF;
  }
  .searchTerm:focus{
    color: #0a0c0c;
  }
  
  .searchButton {
    width: 800px;
    height: 40px;
    border: 2px solid black;
    background: #319c8e;
    text-align: center;
    color: #fff;
    border-radius: 0 5px 5px 0;
    cursor: pointer;
    outline: none;
    font-size: 20px;
  }
  .searchButton i{
      margin-top: 9px;
  }
  .wrap{
    width: 30%;
    position: absolute;
    top: 15%;
    left: 49%;
    transform: translate(-50%, -50%);
  }
  .font{
    font-size: 30px;
    color: black;
    opacity:1;
  }
  .one{
    border: 2px solid black;
    width: 1050px;
    height :absolute;
    margin-top: 9%;
    margin-left: 17%;
    opacity:1;
    overflow-y: hidden;
    border-radius: 20px;
   background-color: white;
   color:black;
}
.two{
    border: 2px solid rgb(107, 109, 109);
    width: 1050px;
    height: 170px;
    margin-top: 5%;
    margin-left: 12%;
    overflow-y: hidden;
}
.three{
    border: 2px solid rgb(107, 109, 109);
    width: 1050px;
    height: 170px;
    margin-top: 5%;
    margin-left: 12%;
    overflow-y: hidden;
}
.four{
    border: 2px solid rgb(107, 109, 109);
    width: 1050px;
    height: 170px;
    margin-top: 5%;
    margin-left: 12%;
    overflow-y: hidden;
}
.five{
    border: 2px solid rgb(107, 109, 109);
    width: 1050px;
    height: 170px;
    margin-top: 5%;
    margin-left: 12%;
    overflow-y: hidden;
}
.content{
    padding:  5px 18px;
    line-height: 1.8;
    
  
}
.line{
    width: 300px;
    height: 2px;
    background-color: #485563;
}
.content p{
  color: #043036;
  font-weight: bold;
}
.iconify{
  font-size: 15px;
}
.heading {
  font-size: 18px;
  margin-top: 0px;
  

}
.loc{
    margin-top: 10px;
}

.fa {
  font-size: 15px;

}
.button{
    display: inline-block;
    margin-left: 850px;
    margin-top: -25px;
}
.button button{
    margin-left: 20px;
}
.button1,.button2,.button3{
    
      font-family: "trebuchet ms";
      font-weight: bold;
      
      padding: 9px 16px;
      border: 1px solid rgb(51, 143, 143);
      background-color: #29323c;
      transition: 0.5s;
      color: rgb(43, 233, 223);
      outline: none;
  }
  .button1:hover,.button2:hover,.button3:hover{
    
      color: #fff;
  }
}

body {
  /* background: linear-gradient(-45deg, #ee7752, #e079cf, #23d5ab);*/
    background-size: 400% 400%;
   /* animation: gradient 15s ease infinite;*/
}

@keyframes gradient {
    0% {
        background-position: 0% 50%;
    }
    50% {
        background-position: 100% 50%;
    }
    100% {
        background-position: 0% 50%;
    }
}

.buttoncls {
    background-color:Teal;
    border: none;
    color: white;
    padding: 15px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 30px;
    margin: 4px 450px;
    cursor: pointer;
	border-radius: 50%;
}
</style>
  <body>
  <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="orphanage details.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
 <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" integrity="sha256-qM7QTJSlvtPSxVRjVWNM2OfTAz/3k5ovHOKmKXuYMO4=" crossorigin="anonymous"></script>
    <!-- (A) SEARCH FORM -->
    
    <section id="header">
    <div class="header container">
    <div class="nav-bar">
     
    <div class="brand">
  
 <a href="#hero"><h1><span>O</span>rphan <span>C</span>onnect</h1></a>
 </div>
    <div class="nav-list">
    <div class="hamburger"><div class="bar"></div></div>
    <ul>
    
    <li><a href="home.html" >Home </a></li>
	<li><a href="orphanmain.php" >My profile</a></li>
    <li><a href="emergency_funds2.php" target="_blank" data-after="Projects">Donation</a></li>
   
    </ul>
    </div>
    </div>
    </div>
    
   
    </section>
    <form action="emergency_information2.php" method="GET" >
    <div class="wrap">
      <div class="search">
<input  type="text" name="keywords" class="searchTerm" placeholder="What are you looking for?">
<button type="submit" class="searchButton">
<i class="fa fa-search"></i>
</button>
</form>
</div>
</div>
    <?php
$conn=mysqli_connect('localhost','root','','medical_emergency');
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
 }
    
    $keywords = isset($_GET['keywords']) ? '%'.$_GET['keywords'].'%' : '';
    
    $result = mysqli_query($conn ,"SELECT * FROM `dbms` where `child_name` like '%".$keywords."%'");
    //$resultset=linkedlist(); 
    while ($row = mysqli_fetch_assoc($result)) {
      ?>
    <form action="#" method="post">
    <div id="list">
    <div class="one">
         <div class="content">
           <h1><div class="font" ><?php echo $row ['child_name']; ?> <br></div></h1>
           <div class="line"></div>
           <p>Date of Birth : 
            <?php echo $row ['Dateofbirth']; ?> <br>
            Gender : 
            <?php echo $row ['Gender']; ?> <br>
            Disease : 
            <?php echo $row ['Disease']; ?> <br>
            Therapeutics : 
            <?php echo $row ['Therapeutics']; ?> <br>
            Amount : 
            <?php echo $row ['Amount']; ?> <br>
            Contact Number : 
            <?php echo $row ['Phone_number']; ?> <br>
            Hospital Name :
			<?php echo $row ['Name']; ?> <br>
			
            </p>
            <br><br>
			<p> Hospital Address : </p>
           <div class="loc"><span class="iconify" data-icon="si-glyph:pin-location-2" data-inline="false"></span>
               <span class="heading" name="hospital location"><?php echo $row ['address']; ?></span></a>
           </div>
            <br>
		   <h2><div class="font">Bank Details</div></h2>
           <div class="line"></div>
           <p>Bank Name : 
            <?php echo $row ['bank_name']; ?> <br>
            Branch : 
            <?php echo $row ['branch']; ?> <br>
            Account Number : 
            <?php echo $row ['account_number']; ?> <br>
            IFSC Code : 
            <?php echo $row ['ifsc_code']; ?> <br>
            Phone Number : 
            <?php echo $row ['phone']; ?> <br>
            </p>
			
			<br>
			<div class="line"></div>
			<br>
		   <h2><div class="font"><center>Remaining Amount</center></div></h2>
           <br>
		   <h2><center><?php echo $row ['remaining_amount']; ?> <br></center></h2><br><br>
		   
			
         </div>
     </div>
    </form>
    <?php } ?>    
  </body>
</html>