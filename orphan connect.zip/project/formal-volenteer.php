<!DOCTYPE html>
<html>
   <!-- <h3>Instructions <br>
        1.<h6>The Volunteer Must be above 18 years</h6><br>
        2.<h6></h6><br>
        3.<br>
        </h3>-->
<head>
 <title>Formal Volunteer</title>
<link rel="stylesheet" href="formal_volenteer.css">
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
a:link, a:visited {
 
 background-color: white;
 color: black;
 border: 2px solid white;
 padding: 10px 20px;
 text-align: center;
 left:200px;
 text-decoration: none;
 display: inline-block;
 font-size: 16px;
}

a:hover, a:active {
 background-color: black;
 color: white;
}

.link-container {
   display:block;
   margin: auto;
   
}

.container {
 padding: 32px;
 transform: translate(150px, -60px);
}
.buttonCls{
       border-radius: 10px;
       width:200px;
       height: 25px;
       background-color:#003366;
       color:white;
       opacity: 0.5;
       font-size:18px;
    }
.button{
background-color: #3BAF9F;
display: block;
margin: 60px 0px 0px 250px;
text-align: center;
border-radius: 12px;
border: 2px solid #366473;
padding: 14px 110px;
outline: none;
color: white;
cursor: pointer;
transition: 0.25px;
}
</style>-->
<body>
<div>
<?php

if(array_key_exists('submit', $_POST)) { 
        SaveFVDetails(); 
    }
function SaveFVDetails()
    { 
         $conn=mysqli_connect('localhost','root','','donation');
          if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
           }
         
		 ?>
    <div class="regform"><h1>Thank you<br><br></h1>
	<h2>Orphanage will shortly contact you<br></h2></div>
	<div align="center">
	<br>
	<a href="donation.html"><div class="buttoncls">DONATE MORE..</div></a>&emsp;&emsp;&emsp;&emsp;<a href="home.html"><div class="buttoncls">HOME</div></a>
	</div>

   <?php
		 
           IF($_POST['first_name']!='')
             { 
              $First_Name=$_POST['first_name'];
              $Last_Name=$_POST['last_name'];
              $Age=$_POST['Age'];
              $Email_id=$_POST['email'];
               $Phone_number=$_POST['phone'];
               $Address=$_POST['Address'];
              $City=$_POST['city'];
               $State=$_POST['state'];
               $Pin_code=$_POST['pin'];
               $No_of_persons=$_POST['persons'];
               $Orphanage_select=$_POST['Orphanselect'];
			mysqli_query($conn,"INSERT INTO formal_Volunteer (`First_Name`, `Last_Name`, `Age`, `Email`, `Phone`, `Address`,`City_or_District`, 
                `State`, `PINCODE`, `Number_of_persons_interested_in_Volunteering`, `Orphanage`)
                   Values ('$First_Name','$Last_Name','$Age', '$Email_id' ,'$Phone_number', '$Address', '$City',
                     '$State' , '$Pin_code' ,'$No_of_persons', '$Orphanage_select')");
        /*echo '<script>alert("Form Submitted Successfully..!!")</script>';*/
        exit;
       
             }
             else
             {
                echo '<script>alert("Please Enter Name.")</script>';
             }
         }
       
?>

<?php
$con= mysqli_connect('localhost','root','','orphanage_');
$s= mysqli_query($con,"SELECT * FROM `orphanage_details`")

?>
</div>
<div class="regform"><h1>Formal Volunteer</h1></div>
<div class="main">
<form action="" Method="POST">
<div id="name">
<h2 class="name">Name</h2>
<input class="firstname" type="text" name="first_name" pattern="[a-zA-Z-' ]{1,}"><br>
<label class="firstlabel">first name</label>
<input class="lastname" type="text" name="last_name" pattern="[a-zA-Z-' ]{1,}">
<label class="lastlabel">last name</label>
</div>

<h2 class="name">Age</h2>
<input class="age" type="number" name="Age" min=18 > 


<h2 class="name">Email</h2>
<input class="email" type="text" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}">

<h2 class="name"> Phone</h2>
<input class="number" type="text" name="phone" pattern="[6-9]{1}[0-9]{9}">
<label class="phone-number">Phone Number</label>

<!--<h2 id="customer">Gender</h2>
<div class="radio1">
<input class="radio1" type="radio"  name="gender" value="Male">
Male
<input class="radio1" type="radio" name="gender" value="Female">
Female
<input class="radio1" type="radio" name="gender" value="Others">
Others
</div>-->
<br><br>
<h2 class="name"> Address</h2>
<input class="Address" type="text" name="Address">
 
<h2 class="name"> city/district</h2>
<input class="city" type="text" name="city">

<h2 class="name"> State</h2>
<input class="state" type="text" name="state" pattern="[a-zA-Z-' ]{1,}">

<h2 class="name"> Pin Code</h2>
<input class="pin" type="text" name="pin" pattern="\d{4}|\d{6}">

<h2 class="name">No Of persons for Volunteer</h2>
<input class="persons" type="number" name="persons" min=1 > 

<h2 class="name">Orphanage Address</h2>
<div class="link container">
<a href="orphanage_details.php" target="_blank">Address</a>
</div>

<h2 class="name">Orphanages</h2>

<div id="myDropdown" class="options-container">
<select class="option1" name ="Orphanselect">
<option>--choose orphanage--</option>
<?php

 while($r= mysqli_fetch_array($s))
 {
   ?>
<option value="<?php echo $r['orphanage_id']; ?>"><?php echo $r['orphanage_name']; ?></option>
<?php
 }
?>
</select>

<!--<h2 class="name">Orphanages</h2>
<div id="myDropdown" class="options-container">
<select class="option1" name ="Orphanselect">
<option>--choose orphanage--</option>
/*<?php

 while($r= mysqli_fetch_array($s))
 {
   ?>
<option value="<?php echo $r['orphanage_id']; ?>"><?php echo $r['orphanage_name']; ?></option>
<?php
 }
?>*/

</select>-->


<br>
<input type="submit"  value="Register" class="button" name="submit" >
<!--</form>
 
<script src="groceries.js"></script>

<button type="submit">Submit</button>-->
</form>
</body>
</html>