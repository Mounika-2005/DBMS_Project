<?php

$conn=mysqli_connect('localhost','root','','donation');
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
 }


?>