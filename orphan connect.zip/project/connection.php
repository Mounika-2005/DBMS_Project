<?php
$con = mysqli_connect('localhost', 'root', '', 'user_login');
?>